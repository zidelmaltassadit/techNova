<?php
session_start();
include("includes/db_connect.php");

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    try {
        $stmt = $conn->prepare("INSERT INTO users (nom, email, password) VALUES (?, ?, ?)");
        $stmt->execute([$nom, $email, $password]);
        $message = "✅ Compte créé avec succès ! Vous pouvez maintenant vous connecter.";
    } catch (PDOException $e) {
        $message = "❌ Erreur : " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription - E-commerce</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        form { width: 400px; margin: 50px auto; background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
        input { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 6px; }
        button { width: 100%; padding: 10px; background: #2F80ED; color: white; border: none; border-radius: 6px; cursor: pointer; }
        button:hover { background: #1C5FCC; }
        .msg { text-align: center; margin-top: 10px; font-weight: bold; }
    </style>
</head>
<body>
    <h2 style="text-align:center;">🧾 Créer un compte</h2>
    <form method="POST">
        <input type="text" name="nom" placeholder="Nom complet" required>
        <input type="email" name="email" placeholder="Adresse e-mail" required>
        <input type="password" name="password" placeholder="Mot de passe" required>
        <button type="submit">Créer mon compte</button>
    </form>
    <p class="msg"><?= $message ?></p>
    <p style="text-align:center;">Déjà un compte ? <a href="login.php">Se connecter</a></p>
</body>
</html>
