<?php
// Fichier : client_secure.php (à la racine)
session_start();

// Vérifie si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    // Si l'utilisateur n'est pas connecté, enregistre la page actuelle pour la redirection après login
    $_SESSION['redirect_to'] = $_SERVER['REQUEST_URI'];
    
    // Redirection vers la page de connexion
    header('Location: login.php');
    exit;
}

// Optionnel mais recommandé : Vérifier si le rôle est 'client' (ou 'admin', car les admins peuvent aussi commander)
// if ($_SESSION['user_role'] !== 'client' && $_SESSION['user_role'] !== 'admin') {
//     header('Location: index.php?error=access_denied');
//     exit;
// }
?>