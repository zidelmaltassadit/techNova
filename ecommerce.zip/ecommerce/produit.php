<?php
// Fichier : produit.php (Détails d'un produit)
session_start();
require_once 'includes/db_connect.php'; 

$produit = null;
$message = '';
$produit_id = intval($_GET['id'] ?? 0);

if ($produit_id > 0) {
    try {
        // Récupérer le produit et son nom de catégorie
        $stmt = $conn->prepare("
            SELECT 
                p.id, p.nom, p.prix, p.description, p.stock, c.nom AS categorie_nom
            FROM 
                produits p
            JOIN 
                categories c ON p.categorie_id = c.id
            WHERE 
                p.id = ?
        ");
        $stmt->execute([$produit_id]);
        $produit = $stmt->fetch();

        if (!$produit) {
            $message = "❌ Produit non trouvé.";
        }

    } catch (PDOException $e) {
        $message = "Erreur de chargement du produit : " . $e->getMessage();
    }
} else {
    $message = "❌ ID de produit manquant.";
}

// require_once 'header.php'; 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détails : <?= htmlspecialchars($produit['nom'] ?? 'Produit') ?></title>
</head>
<body>
    <div class="container">
        <p><a href="catalogue.php">← Retour au Catalogue</a></p>
        
        <?php if ($message): ?>
            <p style="color: red;"><?= $message ?></p>
        <?php endif; ?>

        <?php if ($produit): ?>
            <div style="display: flex; gap: 40px;">
                <div class="image" style="width: 40%;">
                    <img src="placeholder_image.jpg" alt="<?= htmlspecialchars($produit['nom']) ?>" style="width: 100%; border: 1px solid #ccc;">
                </div>
                
                <div class="details" style="width: 60%;">
                    <h1><?= htmlspecialchars($produit['nom']) ?></h1>
                    
                    <p>Catégorie : <strong><?= htmlspecialchars($produit['categorie_nom']) ?></strong></p>
                    <p style="font-size: 2em; color: green; font-weight: bold; margin: 20px 0;"><?= number_format($produit['prix'], 2) ?> €</p>
                    
                    <h3>Description</h3>
                    <p><?= nl2br(htmlspecialchars($produit['description'])) ?></p>
                    
                    <p style="color: <?= ($produit['stock'] > 0) ? 'green' : 'red' ?>;">
                        Stock : <strong><?= $produit['stock'] > 0 ? $produit['stock'] . ' en stock' : 'Rupture de stock' ?></strong>
                    </p>

                    <?php if ($produit['stock'] > 0): ?>
                        <form method="POST" action="ajouter_panier.php" style="margin-top: 30px;">
                            <input type="hidden" name="produit_id" value="<?= $produit['id'] ?>">
                            
                            <label for="quantite" style="font-weight: bold;">Quantité :</label>
                            <input type="number" name="quantite" value="1" min="1" max="<?= $produit['stock'] ?>" style="width: 60px;" required>
                            
                            <button type="submit" style="background-color: orange; color: white; padding: 10px 20px; border: none; margin-left: 20px;">
                                ➕ Ajouter au Panier
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>