<?php
// Fichier : commander.php (à la racine de votre projet)
session_start();
require_once 'includes/db_connect.php'; 
// Assurez-vous d'avoir une table 'clients' pour les adresses
// Assurez-vous d'avoir une table 'commande_details' pour les articles

$message = '';
$panier = $_SESSION['panier'] ?? [];
$total_panier = 0;
$user_id = $_SESSION['user_id'] ?? 0;
$client_infos = [];
$produits_panier = [];

// 1. VÉRIFICATION PRÉALABLE
if ($user_id === 0) {
    // Si l'utilisateur n'est pas connecté, le rediriger vers la connexion
    $_SESSION['redirect_to'] = 'commander.php';
    header('Location: login.php');
    exit;
}
if (count($panier) === 0) {
    // Si le panier est vide
    header('Location: panier.php?error=empty_cart');
    exit;
}

// 2. CHARGEMENT DES DONNÉES CLIENT ET PANIER (Similaire à panier.php)
try {
    // A. Infos Client (pour pré-remplir l'adresse)
    $stmt_client = $conn->prepare("SELECT * FROM clients WHERE user_id = ?");
    $stmt_client->execute([$user_id]);
    $client_infos = $stmt_client->fetch() ?: ['adresse' => '', 'ville' => '', 'code_postal' => '']; // Utilise des valeurs vides si non trouvé

    // B. Infos Produits (pour recalculer le total final et vérifier les prix)
    $ids = implode(',', array_keys($panier));
    $stmt_produits = $conn->query("SELECT id, prix FROM produits WHERE id IN ($ids)");
    $produits_db = $stmt_produits->fetchAll(PDO::FETCH_ASSOC);

    // Calcul final du total
    foreach ($produits_db as $p) {
        $quantite = $panier[$p['id']];
        $sous_total = $p['prix'] * $quantite;
        $total_panier += $sous_total;
        $produits_panier[$p['id']] = ['prix' => $p['prix'], 'quantite' => $quantite];
    }

} catch (PDOException $e) {
    $message = "Erreur de chargement des données : " . $e->getMessage();
}


// 3. TRAITEMENT DE LA COMMANDE (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && count($produits_panier) > 0) {
    
    // Récupération de l'adresse (on suppose qu'elle est dans le formulaire)
    $adresse = trim($_POST['adresse'] ?? $client_infos['adresse']);
    $ville = trim($_POST['ville'] ?? $client_infos['ville']);
    $code_postal = trim($_POST['code_postal'] ?? $client_infos['code_postal']);
    $methode_paiement = trim($_POST['methode_paiement'] ?? 'CB'); // Simplifié

    if (empty($adresse) || empty($ville) || empty($code_postal)) {
        $message = "Veuillez compléter toutes les informations d'adresse.";
    } else {
        // Démarrez la transaction pour assurer l'intégrité BDD
        $conn->beginTransaction();
        try {
            // A. Insertion dans la table `commandes`
            $statut_initial = 'En cours';
            $stmt_insert_cmd = $conn->prepare("INSERT INTO commandes (user_id, total, statut, date_commande) VALUES (?, ?, ?, NOW())");
            $stmt_insert_cmd->execute([$user_id, $total_panier, $statut_initial]);
            $commande_id = $conn->lastInsertId();

            // B. Insertion dans la table `commande_details` et mise à jour des stocks
            $stmt_insert_details = $conn->prepare("INSERT INTO commande_details (commande_id, produit_id, quantite, prix_unitaire) VALUES (?, ?, ?, ?)");
            $stmt_update_stock = $conn->prepare("UPDATE produits SET stock = stock - ? WHERE id = ?");

            foreach ($produits_panier as $produit_id => $data) {
                // Détails
                $stmt_insert_details->execute([$commande_id, $produit_id, $data['quantite'], $data['prix']]);
                
                // Stock
                $stmt_update_stock->execute([$data['quantite'], $produit_id]);
            }
            
            // C. Mise à jour des informations de livraison du client (facultatif mais recommandé)
            $stmt_update_client = $conn->prepare("
                UPDATE clients SET adresse=?, ville=?, code_postal=? WHERE user_id=?
            ");
            $stmt_update_client->execute([$adresse, $ville, $code_postal, $user_id]);

            // D. Valider la transaction
            $conn->commit();
            
            // 4. Succès : Vider le panier et rediriger
            unset($_SESSION['panier']);
            header("Location: confirmation.php?cmd_id=" . $commande_id);
            exit;

        } catch (PDOException $e) {
            $conn->rollBack();
            $message = "❌ Erreur de base de données pendant la commande. Transaction annulée. Détail: " . $e->getMessage();
        }
    }
}

// require_once 'header.php'; // Inclure l'en-tête client
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Passer la Commande</title>
</head>
<body>
    <div class="container">
        <h1>Finaliser ma Commande</h1>
        <p>Total à payer : <strong><?= number_format($total_panier, 2) ?> €</strong></p>

        <?php if ($message): ?>
            <p style="color: red;"><?= $message ?></p>
        <?php endif; ?>

        <form method="POST" action="commander.php">
            
            <h2>1. Adresse de Livraison</h2>
            <label for="adresse">Adresse complète :</label>
            <input type="text" name="adresse" value="<?= htmlspecialchars($client_infos['adresse']) ?>" required><br><br>
            
            <label for="ville">Ville :</label>
            <input type="text" name="ville" value="<?= htmlspecialchars($client_infos['ville']) ?>" required><br><br>
            
            <label for="code_postal">Code Postal :</label>
            <input type="text" name="code_postal" value="<?= htmlspecialchars($client_infos['code_postal']) ?>" required><br><br>

            <h2>2. Mode de Paiement (Simplifié)</h2>
            <select name="methode_paiement" required>
                <option value="CB">Carte Bancaire</option>
                <option value="Virement">Virement Bancaire</option>
            </select><br><br>
            
            <h2>3. Récapitulatif</h2>
            <p>Articles : <?= count($panier) ?> (voir le <a href="panier.php">panier</a>)</p>
            <p style="font-size: 1.5em; font-weight: bold;">TOTAL FINAL : <?= number_format($total_panier, 2) ?> €</p>

            <button type="submit" style="background-color: green; color: white; padding: 15px 30px; border: none; cursor: pointer;">
                Payer et Confirmer la Commande
            </button>
        </form>
    </div>
</body>
</html>