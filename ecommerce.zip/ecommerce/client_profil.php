<?php
// Fichier : client_profil.php (à la racine)
require_once 'client_secure.php'; 
require_once 'includes/db_connect.php'; 

$user_id = $_SESSION['user_id'];
$message = '';

// --- 1. CHARGEMENT DES DONNÉES ACTUELLES ---
$user = [];
$client_infos = [];
try {
    // Récupérer les données de base de l'utilisateur
    $stmt_user = $conn->prepare("SELECT nom, email FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user = $stmt_user->fetch();

    // Récupérer les données d'adresse du client
    $stmt_client = $conn->prepare("SELECT adresse, ville, code_postal FROM clients WHERE user_id = ?");
    $stmt_client->execute([$user_id]);
    $client_infos = $stmt_client->fetch() ?: ['adresse' => '', 'ville' => '', 'code_postal' => ''];
    
    // Si l'utilisateur n'a pas encore d'entrée dans la table 'clients', on la crée pour garantir la mise à jour
    if (!$client_infos['adresse']) {
        $conn->prepare("INSERT INTO clients (user_id) VALUES (?)")->execute([$user_id]);
    }

} catch (PDOException $e) {
    $message = "Erreur de chargement des données : " . $e->getMessage();
}


// --- 2. TRAITEMENT DE LA MISE À JOUR (POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? $user['nom']);
    $email = trim($_POST['email'] ?? $user['email']);
    $adresse = trim($_POST['adresse'] ?? $client_infos['adresse']);
    $ville = trim($_POST['ville'] ?? $client_infos['ville']);
    $code_postal = trim($_POST['code_postal'] ?? $client_infos['code_postal']);
    
    if (empty($nom) || empty($email) || empty($adresse)) {
        $message = "Veuillez remplir les champs obligatoires.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Format d'email invalide.";
    } else {
        $conn->beginTransaction();
        try {
            // Mise à jour de la table 'users'
            $stmt_update_user = $conn->prepare("UPDATE users SET nom=?, email=? WHERE id=?");
            $stmt_update_user->execute([$nom, $email, $user_id]);

            // Mise à jour/Insertion dans la table 'clients'
            $stmt_update_client = $conn->prepare("UPDATE clients SET adresse=?, ville=?, code_postal=? WHERE user_id=?");
            $stmt_update_client->execute([$adresse, $ville, $code_postal, $user_id]);

            $conn->commit();
            
            // Mettre à jour la session et recharger les données pour le formulaire
            $_SESSION['user_nom'] = $nom;
            $user['nom'] = $nom; $user['email'] = $email;
            $client_infos['adresse'] = $adresse; $client_infos['ville'] = $ville; $client_infos['code_postal'] = $code_postal;
            
            $message = "✅ Votre profil a été mis à jour avec succès !";
            
        } catch (PDOException $e) {
            $conn->rollBack();
            $message = "❌ Erreur BDD lors de la mise à jour : " . $e->getMessage();
        }
    }
}

// require_once 'header.php'; // Inclure l'en-tête client
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier mon Profil</title>
</head>
<body>
    <div class="container">
        <h1>Modification de mon Profil</h1>
        <p><a href="client_dashboard.php">← Retour à l'Espace Client</a></p>
        
        <?php if ($message): ?>
            <p style="color: <?= (strpos($message, '✅') !== false) ? 'green' : 'red' ?>;"><?= $message ?></p>
        <?php endif; ?>

        <?php if ($user): ?>
            <form method="POST" action="client_profil.php">
                
                <h2>Informations du Compte</h2>
                <label for="nom">Nom Complet :</label>
                <input type="text" name="nom" value="<?= htmlspecialchars($user['nom']) ?>" required><br><br>
                
                <label for="email">Email :</label>
                <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br><br>

                <h2>Adresse de Livraison/Facturation</h2>
                <label for="adresse">Adresse :</label>
                <input type="text" name="adresse" value="<?= htmlspecialchars($client_infos['adresse']) ?>"><br><br>
                
                <label for="ville">Ville :</label>
                <input type="text" name="ville" value="<?= htmlspecialchars($client_infos['ville']) ?>"><br><br>
                
                <label for="code_postal">Code Postal :</label>
                <input type="text" name="code_postal" value="<?= htmlspecialchars($client_infos['code_postal']) ?>"><br><br>
                
                <input type="submit" value="Enregistrer les Modifications">
            </form>
        <?php endif; ?>
    </div>
</body>
</html>