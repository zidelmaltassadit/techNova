<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site E-commerce</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header>
    <h2><a href="index.php">E-Commerce</a></h2>
    <nav>
        <a href="index.php">Accueil</a>
        <a href="pages/catalogue.php">Catalogue</a>
        <a href="pages/panier.php">Panier</a>
        <a href="login.php">Connexion</a>
    </nav>
</header>
<main>
