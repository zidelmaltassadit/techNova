<?php
$host = "localhost";      // Adresse du serveur MySQL
$user = "root";           // Nom d'utilisateur par défaut sous AMPPS
$pass = "mysql";          // Mot de passe par défaut sous AMPPS
$dbname = "ecommerce_db"; // Nom de ta base de données

try {
    // Création de la connexion avec PDO
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Connexion réussie !"; // (tu peux décommenter pour tester)
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}
?>
