</main>
<footer>
    <p>&copy; 2025 - Site E-commerce | Tous droits réservés</p>
</footer>
</body>
</html>
