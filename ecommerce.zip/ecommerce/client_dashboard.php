<?php
// Fichier : client_dashboard.php (à la racine)
require_once 'client_secure.php'; // Sécurité Client
require_once 'includes/db_connect.php'; 
// Assurez-vous d'inclure votre header client ici : require_once 'header.php'; 

$nb_commandes = 0;
$total_depense = 0;

try {
    // 1. Compter le nombre de commandes
    $stmt_nb_cmd = $conn->prepare("SELECT COUNT(*) FROM commandes WHERE user_id = ?");
    $stmt_nb_cmd->execute([$_SESSION['user_id']]);
    $nb_commandes = $stmt_nb_cmd->fetchColumn();

    // 2. Calculer le total des dépenses (somme des totaux des commandes livrées/traitées)
    $stmt_total = $conn->prepare("SELECT SUM(total) FROM commandes WHERE user_id = ? AND statut IN ('Livrée', 'Traitée', 'Envoyée')");
    $stmt_total->execute([$_SESSION['user_id']]);
    $total_depense = $stmt_total->fetchColumn() ?: 0; // Si le résultat est null, on met 0
    
} catch (PDOException $e) {
    // En cas d'erreur de BDD, les variables restent à 0
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon Espace Client</title>
</head>
<body>
    <div class="container">
        <h1>Bienvenue dans votre Espace Client, <?= htmlspecialchars($_SESSION['user_nom']) ?> ! 👋</h1>

        <div class="dashboard-stats" style="display: flex; gap: 20px; margin-bottom: 30px;">
            <div class="card" style="border: 1px solid #ccc; padding: 20px;">
                <h3>Mes Commandes</h3>
                <p style="font-size: 2em; font-weight: bold;"><?= $nb_commandes ?></p>
                <a href="client_commandes.php">Voir l'historique</a>
            </div>
            
            <div class="card" style="border: 1px solid #ccc; padding: 20px;">
                <h3>Total Dépensé</h3>
                <p style="font-size: 2em; font-weight: bold; color: green;"><?= number_format($total_depense, 2) ?> €</p>
                <p>Cumul des commandes finalisées</p>
            </div>
        </div>

        <h2>Mon Compte</h2>
        <ul style="list-style: none; padding: 0;">
            <li><a href="client_commandes.php">📦 Suivre mes commandes</a></li>
            <li><a href="client_profil.php">⚙️ Modifier mes informations personnelles (Nom, Email, Adresse)</a></li>
            <li><a href="client_motdepasse.php">🔑 Changer mon mot de passe</a></li>
            <li><a href="logout.php">🚪 Déconnexion</a></li>
        </ul>
    </div>
</body>
</html>