<?php
// Fichier : mise_a_jour_panier.php (à la racine de votre projet)
session_start();

if (!isset($_SESSION['panier'])) {
    header('Location: panier.php');
    exit;
}

// Récupérer les données du formulaire de panier
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produit_id = intval($_POST['produit_id'] ?? 0);
    $action = $_POST['action'] ?? ''; // Peut être 'update' ou 'delete'
    $nouvelle_quantite = intval($_POST['quantite'] ?? 0);

    if ($produit_id > 0 && isset($_SESSION['panier'][$produit_id])) {
        if ($action === 'delete') {
            // 1. Suppression
            unset($_SESSION['panier'][$produit_id]);
            $_SESSION['message'] = "✅ Article retiré du panier.";
            
        } elseif ($action === 'update' && $nouvelle_quantite > 0) {
            // 2. Mise à jour (si la quantité est positive)
            $_SESSION['panier'][$produit_id] = $nouvelle_quantite;
            $_SESSION['message'] = "✅ Quantité mise à jour.";
            
        } elseif ($action === 'update' && $nouvelle_quantite <= 0) {
            // Si la quantité est mise à 0, on le retire
            unset($_SESSION['panier'][$produit_id]);
            $_SESSION['message'] = "✅ Article retiré du panier.";
        }
    }
}

header('Location: panier.php');
exit;