<?php
// Inclure le fichier de connexion
require_once 'includes/db_connect.php';

// Si la ligne die() n'a pas été exécutée dans db_connect.php, la connexion est établie.

// Testons une requête simple sur la table users
try {
    $stmt = $pdo->query("SELECT COUNT(*) AS total_users FROM users");
    $result = $stmt->fetch();
    
    echo "<h1>Test de Connexion et Requête Réussi !</h1>";
    echo "<p>La base de données contient actuellement **{$result['total_users']}** utilisateurs enregistrés.</p>";
    
} catch (PDOException $e) {
    echo "Erreur lors de l'exécution de la requête : " . $e->getMessage();
}

?>