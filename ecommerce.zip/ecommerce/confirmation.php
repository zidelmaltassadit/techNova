<?php
// Fichier : confirmation.php (à la racine de votre projet)
session_start();
require_once 'includes/db_connect.php'; 

$commande_id = intval($_GET['cmd_id'] ?? 0);
$details = null;

if ($commande_id > 0) {
    try {
        $stmt = $conn->prepare("SELECT total, date_commande FROM commandes WHERE id = ? AND user_id = ?");
        $stmt->execute([$commande_id, $_SESSION['user_id'] ?? 0]);
        $details = $stmt->fetch();
    } catch (PDOException $e) {
        // Gérer l'erreur
    }
}
// require_once 'header.php'; // Inclure l'en-tête client
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Confirmation de Commande</title>
</head>
<body>
    <div class="container" style="text-align: center; padding: 50px;">
        <?php if ($details): ?>
            <h1>🎉 Commande Confirmée !</h1>
            <p style="font-size: 1.2em;">Merci pour votre achat ! Votre commande a été enregistrée avec succès.</p>
            <div style="border: 1px dashed #ccc; padding: 20px; display: inline-block; margin-top: 20px;">
                <p>Numéro de commande : <strong>#<?= $commande_id ?></strong></p>
                <p>Date : <?= date('d/m/Y H:i', strtotime($details['date_commande'])) ?></p>
                <p>Montant total : <strong style="color: green; font-size: 1.3em;"><?= number_format($details['total'], 2) ?> €</strong></p>
            </div>
            
            <p style="margin-top: 30px;">
                Vous pouvez suivre le statut de votre commande dans votre espace client.
            </p>
            <a href="index.php" style="margin-right: 20px;">Retour à l'accueil</a>
            <a href="client_commandes.php">Voir mes commandes</a>

        <?php else: ?>
            <h1>Erreur</h1>
            <p>Impossible de trouver les détails de la commande ou vous n'êtes pas autorisé à la voir.</p>
            <a href="index.php">Retour à l'accueil</a>
        <?php endif; ?>
    </div>
</body>
</html>