<?php
// Fichier : client_commandes.php (à la racine)
require_once 'client_secure.php'; 
require_once 'includes/db_connect.php'; 
// require_once 'header.php'; 

$commandes = [];
$message = '';

try {
    // Récupération de toutes les commandes de l'utilisateur actuel
    $stmt = $conn->prepare("
        SELECT 
            id, date_commande, total, statut
        FROM 
            commandes 
        WHERE 
            user_id = ?
        ORDER BY 
            date_commande DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $commandes = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $message = "Erreur lors de la récupération de vos commandes : " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Commandes</title>
    <style>
        .statut-en_cours { color: orange; }
        .statut-traitee { color: blue; }
        .statut-envoyée { color: #8a2be2; } /* violet */
        .statut-livrée { color: green; }
        .statut-annulée { color: red; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Mon Historique de Commandes</h1>
        <p><a href="client_dashboard.php">← Retour au tableau de bord</a></p>
        
        <?php if ($message): ?>
            <p style="color: red;"><?= $message ?></p>
        <?php endif; ?>

        <?php if (count($commandes) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Commande</th>
                        <th>Date</th>
                        <th>Statut</th>
                        <th>Total</th>
                        <th>Détails</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($commandes as $cmd): ?>
                        <tr>
                            <td>#<?= $cmd['id'] ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($cmd['date_commande'])) ?></td>
                            <td>
                                <span class="statut-<?= strtolower(str_replace(' ', '_', $cmd['statut'])) ?>">
                                    <?= htmlspecialchars($cmd['statut']) ?>
                                </span>
                            </td>
                            <td><?= number_format($cmd['total'], 2) ?> €</td>
                            <td>
                                <a href="commande_details.php?id=<?= $cmd['id'] ?>" class="btn-info">Voir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Vous n'avez pas encore passé de commande.</p>
        <?php endif; ?>
    </div>
</body>
</html>