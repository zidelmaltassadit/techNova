<?php
session_start();
// Assurez-vous que le chemin vers db_connect.php est correct
include("includes/db_connect.php"); 

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Utilisation d'une requête préparée pour prévenir l'injection SQL
    $stmt = $conn->prepare("SELECT id, nom, password, role FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // Connexion réussie : Initialisation des variables de session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_nom'] = $user['nom'];
        $_SESSION['user_role'] = $user['role']; // CRUCIAL : Stocke le rôle

        // --- NOUVELLE LOGIQUE DE REDIRECTION PAR RÔLE ---
        if ($user['role'] === 'admin') {
            // Redirection vers le tableau de bord du PGI Admin
            header("Location: pages/admin/dashboard.php");
        } else {
            // Redirection pour les clients classiques
            header("Location: index.php");
        }
        exit;
    } else {
        $message = "❌ Identifiants incorrects";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - E-commerce</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Styles CSS directement inclus pour la clarté */
        form { width: 400px; margin: 50px auto; background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
        input { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 6px; }
        button { width: 100%; padding: 10px; background: #2F80ED; color: white; border: none; border-radius: 6px; cursor: pointer; }
        button:hover { background: #1C5FCC; }
        .msg { text-align: center; margin-top: 10px; font-weight: bold; }
    </style>
</head>
<body>
    <h2 style="text-align:center;">🔐 Connexion</h2>
    <form method="POST">
        <input type="email" name="email" placeholder="Adresse e-mail" required>
        <input type="password" name="password" placeholder="Mot de passe" required>
        <button type="submit">Se connecter</button>
    </form>
    <p class="msg"><?= $message ?></p>
    <p style="text-align:center;">Pas encore de compte ? <a href="register.php">S’inscrire</a></p>
</body>
</html>