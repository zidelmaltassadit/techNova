<?php
session_start();
include("../includes/db_connect.php");

// Vérifier si le panier existe et n'est pas vide
if (empty($_SESSION['panier'])) {
    header("Location: panier.php");
    exit;
}

// Simuler un utilisateur connecté (en attendant un vrai login)
$user_id = 1; // à remplacer plus tard par $_SESSION['user_id']

// Récupérer les produits du panier
$ids = implode(',', array_keys($_SESSION['panier']));
$req = $conn->query("SELECT * FROM produits WHERE id IN ($ids)");
$produits = $req->fetchAll();

// Calcul du total
$total = 0;
foreach ($produits as $p) {
    $total += $p['prix'] * $_SESSION['panier'][$p['id']];
}

// Lorsqu'on clique sur "Confirmer la commande"
if (isset($_POST['confirmer'])) {
    try {
        $conn->beginTransaction();

        // Insérer la commande
        $stmt = $conn->prepare("INSERT INTO commandes (user_id, total) VALUES (?, ?)");
        $stmt->execute([$user_id, $total]);
        $commande_id = $conn->lastInsertId();

        // Insérer les lignes de commande
        $stmtLigne = $conn->prepare("INSERT INTO ligne_commande (commande_id, produit_id, quantite, prix_unitaire) VALUES (?, ?, ?, ?)");
        foreach ($produits as $p) {
            $stmtLigne->execute([
                $commande_id,
                $p['id'],
                $_SESSION['panier'][$p['id']],
                $p['prix']
            ]);
        }

        // Vider le panier
        $_SESSION['panier'] = [];

        $conn->commit();
        $message = "✅ Commande enregistrée avec succès ! Merci pour votre achat.";
    } catch (Exception $e) {
        $conn->rollBack();
        $message = "❌ Erreur lors de la commande : " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paiement - E-commerce</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; }
        h1 { text-align: center; margin-top: 30px; }
        table { width: 80%; margin: 30px auto; border-collapse: collapse; background: white; }
        th, td { padding: 12px; border-bottom: 1px solid #ddd; text-align: center; }
        tr:hover { background: #f1f1f1; }
        .total { text-align: right; margin-right: 10%; font-size: 18px; }
        form { text-align: center; margin-top: 20px; }
        button { background: #2F80ED; color: white; padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; }
        button:hover { background: #1C5FCC; }
        .msg { text-align: center; margin-top: 20px; font-weight: bold; }
        a { color: #2F80ED; text-decoration: none; }
    </style>
</head>
<body>

<h1>💳 Paiement</h1>

<?php if (isset($message)): ?>
    <p class="msg"><?= $message ?></p>
    <div style="text-align:center;">
        <a href="../index.php">← Retour à l’accueil</a>
    </div>
<?php else: ?>
    <table>
        <tr>
            <th>Produit</th>
            <th>Prix unitaire</th>
            <th>Quantité</th>
            <th>Sous-total</th>
        </tr>
        <?php foreach ($produits as $p): ?>
        <tr>
            <td><?= htmlspecialchars($p['nom']) ?></td>
            <td><?= number_format($p['prix'], 2, ',', ' ') ?> €</td>
            <td><?= $_SESSION['panier'][$p['id']] ?></td>
            <td><?= number_format($p['prix'] * $_SESSION['panier'][$p['id']], 2, ',', ' ') ?> €</td>
        </tr>
        <?php endforeach; ?>
    </table>

    <p class="total"><strong>Total à payer :</strong> <?= number_format($total, 2, ',', ' ') ?> €</p>

    <form method="post">
        <button type="submit" name="confirmer">✅ Confirmer la commande</button>
    </form>

    <div style="text-align:center;margin-top:15px;">
        <a href="panier.php">← Retour au panier</a>
    </div>
<?php endif; ?>

</body>
</html>
