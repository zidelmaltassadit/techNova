<?php
session_start();
include("../includes/db_connect.php");

// Vérifier si le panier est vide
if (!isset($_SESSION['panier']) || empty($_SESSION['panier'])) {
    header("Location: panier.php");
    exit;
}

// Si l’utilisateur n’est pas connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$produits_ids = array_keys($_SESSION['panier']);
$placeholders = implode(',', array_fill(0, count($produits_ids), '?'));

// Récupération des produits
$stmt = $conn->prepare("SELECT * FROM produits WHERE id IN ($placeholders)");
$stmt->execute($produits_ids);
$produits = $stmt->fetchAll();

$total = 0;
foreach ($produits as $p) {
    $total += $p['prix'] * $_SESSION['panier'][$p['id']];
}

// Enregistrement de la commande si le formulaire est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $adresse = trim($_POST['adresse']);
    $ville = trim($_POST['ville']);
    $cp = trim($_POST['code_postal']);
    $date = date('Y-m-d H:i:s');

    $insertCmd = $conn->prepare("INSERT INTO commandes (user_id, total, date_commande, adresse, ville, code_postal) VALUES (?, ?, ?, ?, ?, ?)");
    $insertCmd->execute([$user_id, $total, $date, $adresse, $ville, $cp]);

    $commande_id = $conn->lastInsertId();

    // Enregistrement des détails
    $insertDetail = $conn->prepare("INSERT INTO commande_details (commande_id, produit_id, quantite, prix_unitaire) VALUES (?, ?, ?, ?)");
    foreach ($produits as $p) {
        $insertDetail->execute([$commande_id, $p['id'], $_SESSION['panier'][$p['id']], $p['prix']]);
        // Mise à jour du stock
        $conn->prepare("UPDATE produits SET stock = stock - ? WHERE id = ?")->execute([$_SESSION['panier'][$p['id']], $p['id']]);
    }

    // Vider le panier
    $_SESSION['panier'] = [];

    header("Location: confirmation.php?id=$commande_id");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Validation de commande - E-commerce</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        main {
            max-width: 800px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #2F80ED;
            margin-bottom: 25px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        input, textarea {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1em;
            width: 100%;
        }
        label {
            font-weight: bold;
        }
        .btn {
            width: fit-content;
            align-self: flex-end;
            background: #27AE60;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: #1F8A50;
        }
        .resume {
            background: #f9f9f9;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .resume table {
            width: 100%;
            border-collapse: collapse;
        }
        .resume th, .resume td {
            border-bottom: 1px solid #eee;
            padding: 10px;
            text-align: left;
        }
        .total {
            text-align: right;
            font-weight: bold;
        }
    </style>
</head>
<body>

<header>
    <h2><a href="../index.php" style="color:white;text-decoration:none;">🛍️ E-Commerce</a></h2>
    <nav>
        <a href="../index.php">Accueil</a>
        <a href="panier.php">Panier (<?= isset($_SESSION['panier']) ? array_sum($_SESSION['panier']) : 0; ?>)</a>
        <a href="../logout.php">Déconnexion</a>
    </nav>
</header>

<main>
    <h1>💳 Validation de votre commande</h1>

    <div class="resume">
        <h3>Résumé de la commande :</h3>
        <table>
            <tr><th>Produit</th><th>Quantité</th><th>Prix (€)</th><th>Total (€)</th></tr>
            <?php foreach ($produits as $p): ?>
                <tr>
                    <td><?= htmlspecialchars($p['nom']) ?></td>
                    <td><?= $_SESSION['panier'][$p['id']] ?></td>
                    <td><?= number_format($p['prix'], 2, ',', ' ') ?></td>
                    <td><?= number_format($p['prix'] * $_SESSION['panier'][$p['id']], 2, ',', ' ') ?></td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="3" class="total">Total :</td>
                <td><strong><?= number_format($total, 2, ',', ' ') ?> €</strong></td>
            </tr>
        </table>
    </div>

    <form method="POST">
        <label for="adresse">Adresse de livraison :</label>
        <textarea id="adresse" name="adresse" required></textarea>

        <label for="ville">Ville :</label>
        <input type="text" id="ville" name="ville" required>

        <label for="code_postal">Code postal :</label>
        <input type="text" id="code_postal" name="code_postal" required>

        <button type="submit" class="btn">✅ Confirmer la commande</button>
    </form>
</main>

<footer>
    © <?= date('Y'); ?> - E-commerce | Tous droits réservés
</footer>

</body>
</html>
