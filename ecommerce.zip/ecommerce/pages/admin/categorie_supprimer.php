<?php
// Fichier : pages/admin/categorie_supprimer.php
require_once 'securite.php';
require_once '../../includes/db_connect.php';

$categorie_id = intval($_GET['id'] ?? 0);

if ($categorie_id > 0) {
    try {
        // Option 1 : Vérifier d'abord s'il y a des produits associés (recommandé)
        $nb_produits = $conn->prepare("SELECT COUNT(*) FROM produits WHERE categorie_id = ?");
        $nb_produits->execute([$categorie_id]);
        
        if ($nb_produits->fetchColumn() > 0) {
            $_SESSION['message'] = "❌ Impossible de supprimer la catégorie : des produits lui sont encore associés. Changez d'abord leur catégorie.";
        } else {
            // Option 2 : Supprimer si aucun produit n'est associé
            $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$categorie_id]);
            $_SESSION['message'] = "✅ Catégorie supprimée avec succès !";
        }

    } catch (PDOException $e) {
        $_SESSION['message'] = "❌ Erreur de suppression BDD : " . $e->getMessage();
    }
} else {
    $_SESSION['message'] = "❌ ID de catégorie manquant ou invalide.";
}

header('Location: categories.php');
exit;
?>