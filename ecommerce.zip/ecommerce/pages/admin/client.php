<?php
include("securite.php");
include("../../includes/db_connect.php");

// ✅ Suppression d’un client
if (isset($_GET['supprimer'])) {
    $id = intval($_GET['supprimer']);
    $conn->query("DELETE FROM clients WHERE id = $id");
    header("Location: clients.php");
    exit;
}

// ✅ Ajout d’un nouveau client
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['ajouter'])) {
    $user_id = intval($_POST['user_id']);
    $telephone = $_POST['telephone'];
    $adresse = $_POST['adresse'];
    $ville = $_POST['ville'];
    $code_postal = $_POST['code_postal'];

    $sql = "INSERT INTO clients (user_id, telephone, adresse, ville, code_postal)
            VALUES (:user_id, :telephone, :adresse, :ville, :code_postal)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':user_id' => $user_id,
        ':telephone' => $telephone,
        ':adresse' => $adresse,
        ':ville' => $ville,
        ':code_postal' => $code_postal
    ]);

    header("Location: clients.php");
    exit;
}

// ✅ Récupération de la liste des clients
$clients = $conn->query("
    SELECT c.id, u.nom AS utilisateur, u.email, c.telephone, c.ville, c.code_postal
    FROM clients c
    LEFT JOIN users u ON c.user_id = u.id
    ORDER BY c.id DESC
")->fetchAll();

// ✅ Liste des utilisateurs “client” (pour ajout)
$utilisateurs = $conn->query("SELECT id, nom FROM users WHERE role = 'client'")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des clients - Admin</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f9f9f9; margin: 0; }
        main { padding: 20px; }
        h2 { text-align: center; margin-top: 20px; }
        table { width: 90%; margin: 20px auto; border-collapse: collapse; background: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        th { background: #2F80ED; color: white; }
        tr:hover { background: #f2f8ff; }
        form { background: white; width: 80%; margin: 30px auto; padding: 20px; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
        input, select, textarea { width: 100%; padding: 8px; margin: 6px 0; border-radius: 5px; border: 1px solid #ccc; }
        button { background: #2F80ED; color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer; }
        button:hover { background: #1C5FCC; }
        a.btn { color: white; background: #E74C3C; padding: 6px 10px; border-radius: 5px; text-decoration: none; }
        a.btn:hover { background: #C0392B; }
    </style>
</head>
<body>

<?php include("admin_header.php"); ?>

<main>
    <h2>👥 Gestion des Clients</h2>

    <!-- ✅ Formulaire d’ajout -->
    <form method="POST">
        <h3>➕ Ajouter un client</h3>
        <label>Utilisateur existant :</label>
        <select name="user_id" required>
            <option value="">-- Sélectionner un utilisateur --</option>
            <?php foreach ($utilisateurs as $u): ?>
                <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['nom']) ?></option>
            <?php endforeach; ?>
        </select>

        <label>Téléphone :</label>
        <input type="text" name="telephone" required>

        <label>Adresse :</label>
        <textarea name="adresse" required></textarea>

        <label>Ville :</label>
        <input type="text" name="ville" required>

        <label>Code postal :</label>
        <input type="text" name="code_postal" required>

        <button type="submit" name="ajouter">Ajouter le client</button>
    </form>

    <!-- ✅ Liste des clients -->
    <table>
        <tr>
            <th>ID</th>
            <th>Nom utilisateur</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Ville</th>
            <th>Code Postal</th>
            <th>Actions</th>
        </tr>

        <?php if (empty($clients)): ?>
            <tr><td colspan="7">Aucun client enregistré pour le moment.</td></tr>
        <?php else: ?>
            <?php foreach ($clients as $c): ?>
                <tr>
                    <td><?= $c['id'] ?></td>
                    <td><?= htmlspecialchars($c['utilisateur']) ?></td>
                    <td><?= htmlspecialchars($c['email']) ?></td>
                    <td><?= htmlspecialchars($c['telephone']) ?></td>
                    <td><?= htmlspecialchars($c['ville']) ?></td>
                    <td><?= htmlspecialchars($c['code_postal']) ?></td>
                    <td>
                        <a class="btn" href="clients.php?supprimer=<?= $c['id'] ?>" onclick="return confirm('Supprimer ce client ?')">Supprimer</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </table>
</main>

</body>
</html>
