<?php
// Fichier : pages/admin/produit_supprimer.php
require_once 'securite.php';
require_once '../../includes/db_connect.php';

// Récupération et validation de l'ID
$produit_id = intval($_GET['id'] ?? 0);

if ($produit_id > 0) {
    try {
        // Préparation de la suppression (Attention aux clés étrangères! Si le produit a des commandes, ça peut échouer)
        $stmt = $conn->prepare("DELETE FROM produits WHERE id = ?");
        $stmt->execute([$produit_id]);
        
        // Redirection après succès
        header('Location: produits.php?success=deleted');
        exit;

    } catch (PDOException $e) {
        // Gérer l'erreur si le produit est lié à d'autres tables (ex: commande_details)
        $_SESSION['error_message'] = "Erreur de suppression : Le produit pourrait être lié à des commandes existantes. " . $e->getMessage();
        header('Location: produits.php');
        exit;
    }
} else {
    header('Location: produits.php?error=id_missing');
    exit;
}
?>