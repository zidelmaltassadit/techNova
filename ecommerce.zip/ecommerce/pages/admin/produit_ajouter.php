<?php
// pages/admin/produit_ajouter.php
require_once 'securite.php';
require_once '../../includes/db_connect.php';

$message = '';

// Récupérer la liste des catégories pour le formulaire
$categories = $conn->query("SELECT id, nom FROM categories")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $prix = floatval($_POST['prix'] ?? 0);
    $stock = intval($_POST['stock'] ?? 0);
    $seuil = intval($_POST['seuil'] ?? 5); // Seuil par défaut
    $categorie_id = intval($_POST['categorie_id'] ?? 0);
    
    // Simplification : Gestion de l'image (upload) omise ici pour se concentrer sur la BDD
    
    if (empty($nom) || $prix <= 0 || $categorie_id === 0) {
        $message = "Veuillez remplir tous les champs obligatoires correctement.";
    } else {
        try {
            $stmt = $conn->prepare("INSERT INTO produits (nom, description, prix, stock, seuil, categorie_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$nom, $description, $prix, $stock, $seuil, $categorie_id]);
            
            // Succès
            header('Location: produits.php?action=added');
            exit;
            
        } catch (PDOException $e) {
            $message = "Erreur lors de l'ajout du produit : " . $e->getMessage();
        }
    }
}

require_once '../../includes/header.php';
?>

<h2>Ajouter un Nouveau Produit</h2>
<form method="POST" action="produit_ajouter.php">
    <label for="nom">Nom du produit :</label>
    <input type="text" name="nom" required><br><br>
    
    <label for="description">Description :</label>
    <textarea name="description"></textarea><br><br>

    <label for="prix">Prix :</label>
    <input type="number" step="0.01" name="prix" required><br><br>
    
    <label for="stock">Stock initial :</label>
    <input type="number" name="stock" required><br><br>
    
    <label for="seuil">Seuil d'alerte :</label>
    <input type="number" name="seuil" value="5" required><br><br>

    <label for="categorie_id">Catégorie :</label>
    <select name="categorie_id" required>
        <option value="">-- Choisir une catégorie --</option>
        <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['nom']) ?></option>
        <?php endforeach; ?>
    </select><br><br>
    
    <input type="submit" value="Ajouter le Produit">
</form>

<?php require_once '../../includes/footer.php'; ?>