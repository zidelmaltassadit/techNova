<?php
// pages/admin/dashboard.php

// 1. Inclusion des fichiers essentiels
// Les chemins sont basés sur la structure du dossier (../.. pour sortir de pages/admin)
require_once '../../includes/db_connect.php'; 
require_once 'securite.php'; // Vérifie si l'utilisateur est un admin connecté

// 2. Initialisation des variables pour éviter les warnings PHP
$nbProduits = 0;
$nbAlertesStock = 0;
$nbCommandes = 0;
$nbUtilisateurs = 0;
$nbFournisseurs = 0;
$message_erreur = '';

try {
    // 3. Récupération des statistiques via PDO
    
    // Nombre total de Produits
    $nbProduits = $conn->query("SELECT COUNT(id) FROM produits")->fetchColumn();
    
    // Nombre de Commandes en attente (à adapter selon vos statuts exacts)
    $nbCommandes = $conn->query("SELECT COUNT(id) FROM commandes WHERE statut = 'en_attente'")->fetchColumn();
    
    // Nombre total d'Utilisateurs (Clients + Admin)
    $nbUtilisateurs = $conn->query("SELECT COUNT(id) FROM users")->fetchColumn();
    
    // Nombre total de Fournisseurs
    $nbFournisseurs = $conn->query("SELECT COUNT(id) FROM fournisseurs")->fetchColumn();
    
    // CORRECTION : Calcul du nombre d'alertes stock
    // On compte le nombre de produits dont le stock est inférieur ou égal au seuil défini dans la table alertes_stock.
    $stmt_alertes = $conn->query("
        SELECT COUNT(p.id) 
        FROM produits p
        JOIN alertes_stock a ON p.id = a.produit_id
        WHERE p.stock <= a.seuil
    ");
    $nbAlertesStock = $stmt_alertes->fetchColumn(); 

} catch (PDOException $e) {
    // Affiche un message d'erreur si la connexion ou une requête échoue
    $message_erreur = "Erreur de connexion à la base de données ou erreur SQL : " . $e->getMessage();
}

// 4. Inclusion de l'en-tête (pour l'affichage du menu et du style)
require_once 'admin_header.php'; 
?>

<h1>Bienvenue sur votre Tableau de bord PGI, Leila 👋</h1>

<?php if ($message_erreur): ?>
    <div style="color: #dc3545; background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; text-align: center; margin: 20px auto; max-width: 800px; border-radius: 5px;">
        <?= $message_erreur ?>
    </div>
<?php endif; ?>

<div class="stats-grid">
    
    <div class="stat-card" data-type="produits">
        <h4>🛒 Produits</h4>
        <p><?= $nbProduits ?></p>
        <a href="produits.php">Gérer</a>
    </div>

    <div class="stat-card" data-type="alertes">
        <h4>🚨 Alertes Stock</h4>
        <p><?= $nbAlertesStock ?></p>
        <a href="produits.php?filter=stock">Voir</a>
    </div>
    
    <div class="stat-card" data-type="commandes">
        <h4>📦 Commandes en Attente</h4>
        <p><?= $nbCommandes ?></p>
        <a href="commandes.php">Gérer</a>
    </div>

    <div class="stat-card" data-type="utilisateurs">
        <h4>👥 Utilisateurs</h4>
        <p><?= $nbUtilisateurs ?></p>
        <a href="utilisateurs.php">Gérer</a>
    </div>
    
    <div class="stat-card" data-type="fournisseurs">
        <h4>🚚 Fournisseurs</h4>
        <p><?= $nbFournisseurs ?></p>
        <a href="fournisseurs.php">Gérer</a>
    </div>
    
</div>

<?php 
// 6. Inclusion du pied de page
// Assurez-vous que ce fichier existe (le chemin devrait être '../../includes/footer.php' ou équivalent)
// Nous utilisons 'admin_footer.php' pour la convention admin.
require_once '../../includes/footer.php';?>