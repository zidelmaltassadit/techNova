<?php
// Fichier : pages/admin/categorie_ajouter.php
require_once 'securite.php';
require_once '../../includes/db_connect.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    
    if (empty($nom)) {
        $message = "Veuillez entrer le nom de la catégorie.";
    } else {
        try {
            $stmt = $conn->prepare("INSERT INTO categories (nom) VALUES (?)");
            $stmt->execute([$nom]);
            
            $_SESSION['message'] = "✅ Catégorie '{$nom}' ajoutée avec succès !";
            header('Location: categories.php');
            exit;
            
        } catch (PDOException $e) {
            $message = "Erreur lors de l'ajout : " . $e->getMessage();
        }
    }
}

require_once 'admin_header.php';
?>

<div class="content">
    <h2>Ajouter une Nouvelle Catégorie</h2>
    <a href="categories.php">Retour à la liste</a>
    
    <?php if ($message): ?>
        <p style="color: red;"><?= $message ?></p>
    <?php endif; ?>

    <form method="POST" action="categorie_ajouter.php">
        <label for="nom">Nom de la catégorie :</label>
        <input type="text" name="nom" required><br><br>
        
        <input type="submit" value="Ajouter la Catégorie">
    </form>
</div>

</body>
</html>