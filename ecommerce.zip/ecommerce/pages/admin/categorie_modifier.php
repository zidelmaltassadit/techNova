<?php
// Fichier : pages/admin/categorie_modifier.php
require_once 'securite.php'; 
require_once '../../includes/db_connect.php'; 

$message = '';
$categorie = null;
$categorie_id = intval($_GET['id'] ?? 0);

// --- 1. TENTATIVE DE CHARGEMENT DE LA CATÉGORIE ---
if ($categorie_id > 0) {
    try {
        $stmt = $conn->prepare("SELECT nom FROM categories WHERE id = ?");
        $stmt->execute([$categorie_id]);
        $categorie = $stmt->fetch();

        if (!$categorie) {
            $message = "❌ Catégorie non trouvée.";
            $categorie_id = 0;
        }
    } catch (PDOException $e) {
        $message = "Erreur BDD lors du chargement : " . $e->getMessage();
    }
} else {
    $message = "❌ ID de catégorie manquant ou invalide.";
}


// --- 2. TRAITEMENT DE LA MISE À JOUR (POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $categorie_id > 0) {
    $nom_nouveau = trim($_POST['nom'] ?? '');

    if (empty($nom_nouveau)) {
        $message = "Veuillez entrer un nom pour la catégorie.";
    } else {
        try {
            $stmt = $conn->prepare("UPDATE categories SET nom=? WHERE id=?");
            $stmt->execute([$nom_nouveau, $categorie_id]);
            
            $_SESSION['message'] = "✅ Catégorie mise à jour avec succès : {$nom_nouveau}";
            header('Location: categories.php');
            exit;
            
        } catch (PDOException $e) {
            $message = "Erreur lors de la mise à jour : " . $e->getMessage();
        }
    }
    // Si la mise à jour échoue, recharger le formulaire avec les dernières données
    if (empty($message) && !isset($stmt)) {
        $categorie['nom'] = $nom_nouveau; // Met à jour le nom dans le formulaire
    }
}

require_once 'admin_header.php';
?>

<div class="content">
    <h2>Modifier la Catégorie : <?= htmlspecialchars($categorie['nom'] ?? 'N/A') ?></h2>
    <a href="categories.php">Retour à la liste</a>
    
    <?php if ($message): ?>
        <p style="color: <?= (strpos($message, 'succès') !== false) ? 'green' : 'red' ?>;"><?= $message ?></p>
    <?php endif; ?>

    <?php if ($categorie): ?>
        <form method="POST" action="categorie_modifier.php?id=<?= $categorie_id ?>">
            <label for="nom">Nom de la catégorie :</label>
            <input type="text" name="nom" value="<?= htmlspecialchars($categorie['nom']) ?>" required><br><br>
            
            <input type="submit" value="Enregistrer les Modifications">
        </form>
    <?php endif; ?>
</div>

</body>
</html>