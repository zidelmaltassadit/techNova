<?php
// Fichier : pages/admin/categories.php
require_once 'securite.php'; // 🛡️ Sécurité : accès réservé aux Admins
require_once '../../includes/db_connect.php'; // Connexion BDD

// --- 1. Traitement des messages de session (après redirection) ---
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']); // Effacer le message après l'affichage

// --- 2. Récupération des Catégories ---
$categories = [];
try {
    // Jointure pour compter le nombre de produits par catégorie (utile pour l'admin)
    $stmt = $conn->query("
        SELECT 
            c.id, c.nom, 
            COUNT(p.id) AS nb_produits
        FROM 
            categories c 
        LEFT JOIN 
            produits p ON c.id = p.categorie_id
        GROUP BY 
            c.id, c.nom
        ORDER BY 
            c.nom ASC
    ");
    $categories = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $message = "Erreur lors de la récupération des catégories : " . $e->getMessage();
}

require_once 'admin_header.php';
?>

<div class="content">
    <h2>Liste des Catégories</h2>
    
    <a href="categorie_ajouter.php" class="btn-primary">➕ Ajouter une Catégorie</a>
    
    <?php if ($message): ?>
        <p style="color: <?= (strpos($message, 'succès') !== false) ? 'green' : 'red' ?>;"><?= $message ?></p>
    <?php endif; ?>

    <?php if (count($categories) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Nb. Produits Associés</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat): ?>
                    <tr>
                        <td><?= $cat['id'] ?></td>
                        <td><?= htmlspecialchars($cat['nom']) ?></td>
                        <td><?= $cat['nb_produits'] ?></td>
                        <td>
                            <a href="categorie_modifier.php?id=<?= $cat['id'] ?>" class="btn-edit">Modifier</a>
                            | 
                            <a href="categorie_supprimer.php?id=<?= $cat['id'] ?>" 
                                onclick="return confirm('ATTENTION : Supprimer cette catégorie pourrait affecter <?= $cat['nb_produits'] ?> produits. Êtes-vous sûr ?')" 
                                class="btn-delete">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Aucune catégorie trouvée. Ajoutez-en une pour organiser vos produits.</p>
    <?php endif; ?>
</div>

</body>
</html>