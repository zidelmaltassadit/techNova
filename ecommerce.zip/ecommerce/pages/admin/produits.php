<?php
// pages/admin/produits.php
require_once 'securite.php'; // 🛡️ Vérifie si l'utilisateur est Admin et connecté
require_once '../../includes/db_connect.php'; // Connexion BDD
require_once '../../includes/header.php'; // Inclusion de l'en-tête (HTML, CSS, navigation Admin)

// 1. Récupération des Produits et des Catégories associées
try {
    // Jointure pour afficher le nom de la catégorie à la place de l'ID
    $stmt = $conn->query("
        SELECT 
            p.id, p.nom, p.prix, p.stock, p.seuil, c.nom AS nom_categorie
        FROM 
            produits p 
        JOIN 
            categories c ON p.categorie_id = c.id
        ORDER BY 
            p.nom ASC
    ");
    $produits = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error_message = "Erreur lors de la récupération des produits : " . $e->getMessage();
    $produits = [];
}
?>

<h2>Liste des Produits</h2>
<a href="produit_ajouter.php" class="btn-primary">➕ Ajouter un Produit</a>

<?php if (isset($error_message)): ?>
    <p class="error"><?= $error_message ?></p>
<?php endif; ?>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Catégorie</th>
            <th>Prix</th>
            <th>Stock</th>
            <th>Alerte Stock</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($produits as $produit): ?>
            <tr class="<?= ($produit['stock'] <= $produit['seuil']) ? 'stock-alert' : '' ?>">
                <td><?= $produit['id'] ?></td>
                <td><?= htmlspecialchars($produit['nom']) ?></td>
                <td><?= htmlspecialchars($produit['nom_categorie']) ?></td>
                <td><?= number_format($produit['prix'], 2) ?> €</td>
                <td><?= $produit['stock'] ?></td>
                <td><?= $produit['seuil'] ?></td>
                <td>
                    <a href="produit_modifier.php?id=<?= $produit['id'] ?>" class="btn-edit">Modifier</a>
                    | 
                    <a href="supprimer_produit.php?id=<?= $produit['id'] ?>" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce produit ?')" class="btn-delete">Supprimer</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require_once '../../includes/footer.php'; ?>