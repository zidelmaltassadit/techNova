<?php
// Fichier : pages/admin/utilisateurs.php
require_once 'securite.php'; 
require_once '../../includes/db_connect.php'; 
require_once 'admin_header.php'; 

$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

$users = [];

try {
    // Récupérer tous les utilisateurs
    $stmt = $conn->query("SELECT id, nom, email, role, date_creation FROM users ORDER BY role DESC, nom ASC");
    $users = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $message = "Erreur lors de la récupération des utilisateurs : " . $e->getMessage();
}
?>

<div class="content">
    <h2>Gestion des Utilisateurs</h2>
    
    <?php if ($message): ?>
        <p style="color: <?= (strpos($message, 'succès') !== false) ? 'green' : 'red' ?>;"><?= $message ?></p>
    <?php endif; ?>

    <?php if (count($users) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Rôle</th>
                    <th>Date d'Inscription</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= $user['id'] ?></td>
                        <td><?= htmlspecialchars($user['nom']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td>
                            <strong style="color: <?= ($user['role'] === 'admin') ? 'purple' : 'blue' ?>;">
                                <?= htmlspecialchars(ucfirst($user['role'])) ?>
                            </strong>
                        </td>
                        <td><?= date('d/m/Y', strtotime($user['date_creation'])) ?></td>
                        <td>
                            <a href="utilisateur_modifier.php?id=<?= $user['id'] ?>" class="btn-edit">Modifier/Rôle</a>
                            | 
                            <a href="utilisateur_supprimer.php?id=<?= $user['id'] ?>" 
                                onclick="return confirm('Attention ! Supprimer un utilisateur supprime potentiellement ses commandes. Continuer ?')" 
                                class="btn-delete" style="<?= ($user['role'] === 'admin' && $user['id'] === $_SESSION['user_id']) ? 'pointer-events: none; opacity: 0.5;' : '' ?>">
                                Supprimer
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Aucun utilisateur trouvé.</p>
    <?php endif; ?>
</div>

</body>
</html>