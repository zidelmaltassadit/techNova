<?php
// Démarre ou reprend la session
session_start();

// 1. Vérification de l'authentification
if (!isset($_SESSION['user_id'])) {
    // Si l'utilisateur n'est pas connecté, le renvoyer à la page de connexion
    header('Location: ../../login.php'); // Ajustez le chemin si nécessaire
    exit;
}

// 2. Vérification du rôle (Autorisation)
if ($_SESSION['user_role'] !== 'admin') {
    // Si l'utilisateur est connecté mais n'est pas Admin (c'est un Client)
    // Le rediriger vers l'accueil ou afficher une erreur 403
    header('Location: ../../index.php'); // Rediriger le client vers le front-office
    exit;
}

// Si le script arrive ici, l'utilisateur est connecté et est un ADMIN.
// La page peut continuer à se charger.

?>