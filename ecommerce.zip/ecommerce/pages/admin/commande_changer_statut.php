<?php
// Fichier : pages/admin/commande_changer_statut.php
require_once 'securite.php';
require_once '../../includes/db_connect.php';

$commande_id = intval($_GET['id'] ?? 0);
$nouveau_statut = trim($_GET['statut'] ?? '');

$statuts_valides = ['en_cours', 'traitée', 'envoyée', 'livrée', 'annulée'];

if ($commande_id > 0 && in_array(strtolower($nouveau_statut), $statuts_valides)) {
    try {
        $stmt = $conn->prepare("UPDATE commandes SET statut = ? WHERE id = ?");
        $stmt->execute([ucfirst(strtolower($nouveau_statut)), $commande_id]); // Stocke le statut avec la première lettre en majuscule (ex: "Traitée")

        $_SESSION['message'] = "✅ Statut de la commande #{$commande_id} mis à jour : {$nouveau_statut}.";
        
    } catch (PDOException $e) {
        $_SESSION['message'] = "❌ Erreur BDD lors de la mise à jour : " . $e->getMessage();
    }
    
    // Redirection vers la page de détails ou la liste
    header("Location: commande_details.php?id={$commande_id}");
    exit;

} else {
    $_SESSION['message'] = "❌ Paramètres de changement de statut invalides.";
    header('Location: commandes.php');
    exit;
}
?>