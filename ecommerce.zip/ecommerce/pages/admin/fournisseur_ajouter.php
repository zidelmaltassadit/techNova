<?php
// Fichier : pages/admin/fournisseur_ajouter.php
require_once 'securite.php';
require_once '../../includes/db_connect.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Récupération et nettoyage des données
    $nom = trim($_POST['nom'] ?? '');
    $contact = trim($_POST['contact'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    $adresse = trim($_POST['adresse'] ?? '');
    $ville = trim($_POST['ville'] ?? '');
    $code_postal = trim($_POST['code_postal'] ?? '');
    
    // 2. Validation simple
    if (empty($nom) || empty($contact) || empty($email)) {
        $message = "Veuillez remplir les champs Nom, Contact et Email.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Format d'email invalide.";
    } else {
        try {
            // 3. Préparation et Exécution de l'insertion
            $stmt = $conn->prepare("INSERT INTO fournisseurs (nom, contact, email, telephone, adresse, ville, code_postal, date_creation) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            
            $stmt->execute([$nom, $contact, $email, $telephone, $adresse, $ville, $code_postal]);
            
            // 4. Redirection après succès
            header('Location: fournisseurs.php?success=added');
            exit;
            
        } catch (PDOException $e) {
            $message = "Erreur lors de l'ajout du fournisseur : " . $e->getMessage();
        }
    }
}

require_once 'admin_header.php';
?>

<div class="content">
    <h2>Ajouter un Nouveau Fournisseur</h2>
    <a href="fournisseurs.php">Retour à la liste</a>
    
    <?php if ($message): ?>
        <p style="color: red;"><?= $message ?></p>
    <?php endif; ?>

    <form method="POST" action="fournisseur_ajouter.php">
        <label for="nom">Nom de l'Entreprise :</label>
        <input type="text" name="nom" required><br><br>
        
        <label for="contact">Nom du Contact :</label>
        <input type="text" name="contact" required><br><br>
        
        <label for="email">Email :</label>
        <input type="email" name="email" required><br><br>
        
        <label for="telephone">Téléphone :</label>
        <input type="text" name="telephone"><br><br>

        <label for="adresse">Adresse :</label>
        <input type="text" name="adresse"><br><br>
        
        <label for="ville">Ville :</label>
        <input type="text" name="ville"><br><br>
        
        <label for="code_postal">Code Postal :</label>
        <input type="text" name="code_postal"><br><br>
        
        <input type="submit" value="Enregistrer le Fournisseur">
    </form>
</div>

</body>
</html>