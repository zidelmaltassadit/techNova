<?php
// Fichier : pages/admin/utilisateur_modifier.php
require_once 'securite.php'; 
require_once '../../includes/db_connect.php'; 

$message = '';
$user = null;
$user_id = intval($_GET['id'] ?? 0);

// Statuts et rôles possibles
$roles_disponibles = ['client', 'admin'];

// --- 1. CHARGEMENT DE L'UTILISATEUR ---
if ($user_id > 0) {
    try {
        $stmt = $conn->prepare("SELECT id, nom, email, role, date_creation FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        if (!$user) {
            $message = "❌ Utilisateur non trouvé.";
            $user_id = 0;
        }
    } catch (PDOException $e) {
        $message = "Erreur BDD lors du chargement : " . $e->getMessage();
    }
} else {
    $message = "❌ ID utilisateur manquant ou invalide.";
}


// --- 2. TRAITEMENT DE LA MISE À JOUR (POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user_id > 0) {
    // Récupération des données POST
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = trim($_POST['role'] ?? '');

    if (empty($nom) || empty($email) || !in_array($role, $roles_disponibles)) {
        $message = "Veuillez remplir tous les champs obligatoires correctement.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Format d'email invalide.";
    } else {
        try {
            $stmt = $conn->prepare("UPDATE users SET nom=?, email=?, role=? WHERE id=?");
            
            $stmt->execute([$nom, $email, $role, $user_id]);
            
            $_SESSION['message'] = "✅ Utilisateur '{$nom}' mis à jour avec succès !";
            
            // Redirection vers la liste après succès
            header('Location: utilisateurs.php');
            exit;
            
        } catch (PDOException $e) {
            $message = "Erreur lors de la mise à jour : " . $e->getMessage();
        }
    }
}

require_once 'admin_header.php';
?>

<div class="content">
    <h2>Modifier l'Utilisateur : <?= htmlspecialchars($user['nom'] ?? 'N/A') ?></h2>
    <a href="utilisateurs.php">Retour à la liste</a>
    
    <?php if ($message): ?>
        <p style="color: <?= (strpos($message, 'succès') !== false) ? 'green' : 'red' ?>;"><?= $message ?></p>
    <?php endif; ?>

    <?php if ($user): ?>
        <form method="POST" action="utilisateur_modifier.php?id=<?= $user_id ?>">
            
            <label for="nom">Nom :</label>
            <input type="text" name="nom" value="<?= htmlspecialchars($user['nom']) ?>" required><br><br>
            
            <label for="email">Email :</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br><br>
            
            <label for="role">Rôle :</label>
            <select name="role" required>
                <?php foreach ($roles_disponibles as $r): ?>
                    <option value="<?= $r ?>" <?= ($user['role'] == $r) ? 'selected' : '' ?>>
                        <?= ucfirst($r) ?>
                    </option>
                <?php endforeach; ?>
            </select><br><br>
            
            <p>Date d'inscription : <?= date('d/m/Y', strtotime($user['date_creation'])) ?></p>
            
            <input type="submit" value="Enregistrer les Modifications">
        </form>
    <?php endif; ?>
</div>

</body>
</html>