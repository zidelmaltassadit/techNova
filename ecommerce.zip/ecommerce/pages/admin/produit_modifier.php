<?php
// Fichier : pages/admin/produit_modifier.php
require_once 'securite.php'; 
require_once '../../includes/db_connect.php'; 

$message = '';
$produit = null;
$produit_id = intval($_GET['id'] ?? 0);

// --- 1. Récupérer les catégories et le produit EXISTANT ---
try {
    // Récupérer toutes les catégories pour le menu déroulant
    $categories = $conn->query("SELECT id, nom FROM categories ORDER BY nom ASC")->fetchAll();
    
    // Récupérer le produit à modifier
    if ($produit_id > 0) {
        $stmt = $conn->prepare("SELECT * FROM produits WHERE id = ?");
        $stmt->execute([$produit_id]);
        $produit = $stmt->fetch();

        if (!$produit) {
            $message = "❌ Produit non trouvé.";
            $produit_id = 0;
        }
    }
} catch (PDOException $e) {
    $message = "Erreur BDD lors du chargement : " . $e->getMessage();
}


// --- 2. TRAITEMENT DE LA MISE À JOUR (POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $produit_id > 0) {
    // Récupération et conversion des données POST
    $nom = trim($_POST['nom'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $prix = floatval($_POST['prix'] ?? 0);
    $stock = intval($_POST['stock'] ?? 0);
    $seuil = intval($_POST['seuil'] ?? 5); 
    $categorie_id = intval($_POST['categorie_id'] ?? 0);

    if (empty($nom) || $prix <= 0 || $categorie_id === 0) {
        $message = "Veuillez remplir tous les champs obligatoires correctement.";
    } else {
        try {
            // Requête de mise à jour
            $stmt = $conn->prepare("UPDATE produits SET nom=?, description=?, prix=?, stock=?, seuil=?, categorie_id=? WHERE id=?");
            
            $stmt->execute([$nom, $description, $prix, $stock, $seuil, $categorie_id, $produit_id]);
            
            $message = "✅ Produit mis à jour avec succès !";
            
            // Recharger les données du produit mis à jour pour rafraîchir le formulaire
            $stmt_reload = $conn->prepare("SELECT * FROM produits WHERE id = ?");
            $stmt_reload->execute([$produit_id]);
            $produit = $stmt_reload->fetch();
            
        } catch (PDOException $e) {
            $message = "Erreur lors de la mise à jour : " . $e->getMessage();
        }
    }
}

require_once 'admin_header.php';
?>

<div class="content">
    <h2>Modifier le Produit : <?= htmlspecialchars($produit['nom'] ?? 'N/A') ?></h2>
    <a href="produits.php">Retour à la liste des produits</a>
    
    <?php if ($message): ?>
        <p style="color: <?= (strpos($message, '✅') !== false) ? 'green' : 'red' ?>;"><?= $message ?></p>
    <?php endif; ?>

    <?php if ($produit && count($categories) > 0): ?>
        <form method="POST" action="produit_modifier.php?id=<?= $produit_id ?>">
            
            <label for="nom">Nom du produit :</label>
            <input type="text" name="nom" value="<?= htmlspecialchars($produit['nom']) ?>" required><br><br>
            
            <label for="description">Description :</label>
            <textarea name="description"><?= htmlspecialchars($produit['description']) ?></textarea><br><br>

            <label for="prix">Prix :</label>
            <input type="number" step="0.01" name="prix" value="<?= htmlspecialchars($produit['prix']) ?>" required><br><br>
            
            <label for="stock">Stock actuel :</label>
            <input type="number" name="stock" value="<?= htmlspecialchars($produit['stock']) ?>" required><br><br>
            
            <label for="seuil">Seuil d'alerte :</label>
            <input type="number" name="seuil" value="<?= htmlspecialchars($produit['seuil']) ?>" required><br><br>

            <label for="categorie_id">Catégorie :</label>
            <select name="categorie_id" required>
                <option value="">-- Choisir une catégorie --</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= ($produit['categorie_id'] == $cat['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($cat['nom']) ?>
                    </option>
                <?php endforeach; ?>
            </select><br><br>
            
            <input type="submit" value="Enregistrer les Modifications">
        </form>
    <?php elseif ($produit_id > 0): ?>
        <p>Impossible de charger la liste des catégories. Vérifiez la table `categories`.</p>
    <?php endif; ?>
</div>

</body>
</html>