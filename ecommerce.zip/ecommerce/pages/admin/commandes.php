<?php
// Fichier : pages/admin/commandes.php
require_once 'securite.php'; 
require_once '../../includes/db_connect.php'; 

$message = '';
$commandes = [];

try {
    // Requête principale pour joindre les tables 'commandes' et 'users'
    // Permet d'afficher le nom du client qui a passé la commande.
    $stmt = $conn->query("
        SELECT 
            c.id, c.date_commande, c.total, c.statut, u.nom AS client_nom
        FROM 
            commandes c
        JOIN 
            users u ON c.user_id = u.id
        ORDER BY 
            c.date_commande DESC
    ");
    $commandes = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $message = "Erreur lors de la récupération des commandes : " . $e->getMessage();
}

require_once 'admin_header.php';
?>

<div class="content">
    <h2>Gestion des Commandes</h2>
    
    <?php if ($message): ?>
        <p style="color: red;"><?= $message ?></p>
    <?php endif; ?>

    <?php if (count($commandes) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID Commande</th>
                    <th>Date</th>
                    <th>Client</th>
                    <th>Total (EUR)</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($commandes as $cmd): ?>
                    <tr>
                        <td><?= $cmd['id'] ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($cmd['date_commande'])) ?></td>
                        <td><?= htmlspecialchars($cmd['client_nom']) ?></td>
                        <td><?= number_format($cmd['total'], 2) ?> €</td>
                        <td>
                            <span class="statut-<?= strtolower($cmd['statut']) ?>">
                                <?= htmlspecialchars($cmd['statut']) ?>
                            </span>
                        </td>
                        <td>
                            <a href="commande_details.php?id=<?= $cmd['id'] ?>" class="btn-info">Voir Détails</a>
                            <a href="commande_changer_statut.php?id=<?= $cmd['id'] ?>" class="btn-edit">Modifier Statut</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Aucune commande enregistrée pour le moment.</p>
    <?php endif; ?>
</div>

<style>
    /* Styles pour rendre le statut visuel (ajoutez ceci dans admin_header.php ou dans un fichier CSS) */
    .statut-en_cours { color: orange; font-weight: bold; }
    .statut-traitee { color: blue; font-weight: bold; }
    .statut-livree { color: green; font-weight: bold; }
    .statut-annulee { color: red; font-weight: bold; }
</style>

</body>
</html>