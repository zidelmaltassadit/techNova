<?php
// Fichier : pages/admin/fournisseur_modifier.php
require_once 'securite.php'; 
require_once '../../includes/db_connect.php'; 
require_once 'admin_header.php';

$message = '';
$fournisseur = null;
$fournisseur_id = intval($_GET['id'] ?? 0);

// --- 1. TENTATIVE DE RÉCUPÉRATION DU FOURNISSEUR ---
if ($fournisseur_id > 0) {
    try {
        $stmt = $conn->prepare("SELECT * FROM fournisseurs WHERE id = ?");
        $stmt->execute([$fournisseur_id]);
        $fournisseur = $stmt->fetch();

        if (!$fournisseur) {
            $message = "❌ Fournisseur non trouvé.";
            $fournisseur_id = 0; // Invalider l'ID pour ne pas afficher le formulaire
        }
    } catch (PDOException $e) {
        $message = "Erreur BDD lors du chargement : " . $e->getMessage();
    }
} else {
    $message = "❌ ID de fournisseur manquant ou invalide.";
}


// --- 2. TRAITEMENT DE LA MISE À JOUR (POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $fournisseur_id > 0) {
    // Récupération des données POST
    $nom = trim($_POST['nom'] ?? '');
    $contact = trim($_POST['contact'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    $adresse = trim($_POST['adresse'] ?? '');
    $ville = trim($_POST['ville'] ?? '');
    $code_postal = trim($_POST['code_postal'] ?? '');

    if (empty($nom) || empty($contact) || empty($email)) {
        $message = "Veuillez remplir tous les champs obligatoires.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Format d'email invalide.";
    } else {
        try {
            $stmt = $conn->prepare("UPDATE fournisseurs SET nom=?, contact=?, email=?, telephone=?, adresse=?, ville=?, code_postal=? WHERE id=?");
            
            $stmt->execute([
                $nom, $contact, $email, $telephone, $adresse, $ville, $code_postal, $fournisseur_id
            ]);
            
            // Succès : Mise à jour des données locales pour l'affichage immédiat
            $message = "✅ Fournisseur mis à jour avec succès !";
            
            // Recharger les données du fournisseur mis à jour pour rafraîchir le formulaire
            $stmt_reload = $conn->prepare("SELECT * FROM fournisseurs WHERE id = ?");
            $stmt_reload->execute([$fournisseur_id]);
            $fournisseur = $stmt_reload->fetch();
            
        } catch (PDOException $e) {
            $message = "Erreur lors de la mise à jour : " . $e->getMessage();
        }
    }
}

?>

<div class="content">
    <h2>Modifier le Fournisseur</h2>
    <a href="fournisseurs.php">Retour à la liste</a>
    
    <?php if ($message): ?>
        <p style="color: <?= (strpos($message, '✅') !== false) ? 'green' : 'red' ?>;"><?= $message ?></p>
    <?php endif; ?>

    <?php if ($fournisseur): ?>
        <form method="POST" action="fournisseur_modifier.php?id=<?= $fournisseur_id ?>">
            <label for="nom">Nom de l'Entreprise :</label>
            <input type="text" name="nom" value="<?= htmlspecialchars($fournisseur['nom']) ?>" required><br><br>
            
            <label for="contact">Nom du Contact :</label>
            <input type="text" name="contact" value="<?= htmlspecialchars($fournisseur['contact']) ?>" required><br><br>
            
            <label for="email">Email :</label>
            <input type="email" name="email" value="<?= htmlspecialchars($fournisseur['email']) ?>" required><br><br>
            
            <label for="telephone">Téléphone :</label>
            <input type="text" name="telephone" value="<?= htmlspecialchars($fournisseur['telephone']) ?>"><br><br>

            <label for="adresse">Adresse :</label>
            <input type="text" name="adresse" value="<?= htmlspecialchars($fournisseur['adresse']) ?>"><br><br>
            
            <label for="ville">Ville :</label>
            <input type="text" name="ville" value="<?= htmlspecialchars($fournisseur['ville']) ?>"><br><br>
            
            <label for="code_postal">Code Postal :</label>
            <input type="text" name="code_postal" value="<?= htmlspecialchars($fournisseur['code_postal']) ?>"><br><br>
            
            <input type="submit" value="Enregistrer les Modifications">
        </form>
    <?php endif; ?>
</div>

</body>
</html>