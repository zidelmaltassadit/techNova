<?php
// Fichier : pages/admin/commande_details.php
require_once 'securite.php'; 
require_once '../../includes/db_connect.php'; 

$message = '';
$commande = null;
$details = [];
$client = null;

$commande_id = intval($_GET['id'] ?? 0);

if ($commande_id > 0) {
    try {
        // 1. Récupérer la commande principale et le client (jointure commandes + users)
        $stmt_cmd = $conn->prepare("
            SELECT 
                c.*, u.nom AS client_nom, u.email AS client_email,
                cl.adresse, cl.ville, cl.code_postal
            FROM 
                commandes c
            JOIN users u ON c.user_id = u.id
            JOIN clients cl ON c.user_id = cl.user_id
            WHERE c.id = ?
        ");
        $stmt_cmd->execute([$commande_id]);
        $commande = $stmt_cmd->fetch();

        if ($commande) {
            // 2. Récupérer les détails des articles de la commande (jointure commande_details + produits)
            $stmt_details = $conn->prepare("
                SELECT 
                    cd.produit_id, cd.prix_unitaire, cd.quantite,
                    p.nom AS produit_nom
                FROM 
                    commande_details cd
                JOIN 
                    produits p ON cd.produit_id = p.id
                WHERE cd.commande_id = ?
            ");
            $stmt_details->execute([$commande_id]);
            $details = $stmt_details->fetchAll();
        } else {
            $message = "❌ Commande non trouvée.";
        }
        
    } catch (PDOException $e) {
        $message = "Erreur BDD lors du chargement des détails : " . $e->getMessage();
    }
} else {
    $message = "❌ ID de commande manquant ou invalide.";
}

require_once 'admin_header.php';
?>

<div class="content">
    <a href="commandes.php">Retour à la liste des commandes</a>
    <h2>Détails de la Commande #<?= $commande_id ?></h2>
    
    <?php if ($message): ?>
        <p style="color: red;"><?= $message ?></p>
    <?php endif; ?>

    <?php if ($commande): ?>
        <div style="display: flex; justify-content: space-between; gap: 30px;">
            <div style="flex: 1; border: 1px solid #ccc; padding: 15px;">
                <h3>Informations Générales</h3>
                <p><strong>Client :</strong> <?= htmlspecialchars($commande['client_nom']) ?> (<?= htmlspecialchars($commande['client_email']) ?>)</p>
                <p><strong>Date :</strong> <?= date('d/m/Y H:i', strtotime($commande['date_commande'])) ?></p>
                <p><strong>Statut :</strong> <span class="statut-<?= strtolower($commande['statut']) ?>"><?= htmlspecialchars($commande['statut']) ?></span></p>
                <p><strong>Total TTC :</strong> <?= number_format($commande['total'], 2) ?> €</p>
            </div>
            
            <div style="flex: 1; border: 1px solid #ccc; padding: 15px;">
                <h3>Adresse de Livraison</h3>
                <p><?= htmlspecialchars($commande['adresse']) ?></p>
                <p><?= htmlspecialchars($commande['code_postal']) ?> <?= htmlspecialchars($commande['ville']) ?></p>
            </div>
        </div>

        <h3 style="margin-top: 30px;">Articles Commandés</h3>
        <?php if (count($details) > 0): ?>
            <table style="width: 100%;">
                <thead>
                    <tr>
                        <th>Produit</th>
                        <th>Quantité</th>
                        <th>Prix Unitaire</th>
                        <th>Sous-total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $sous_total_commande = 0; ?>
                    <?php foreach ($details as $det): ?>
                        <?php $sous_total_ligne = $det['prix_unitaire'] * $det['quantite']; $sous_total_commande += $sous_total_ligne; ?>
                        <tr>
                            <td><a href="produit_modifier.php?id=<?= $det['produit_id'] ?>"><?= htmlspecialchars($det['produit_nom']) ?></a></td>
                            <td><?= $det['quantite'] ?></td>
                            <td><?= number_format($det['prix_unitaire'], 2) ?> €</td>
                            <td><?= number_format($sous_total_ligne, 2) ?> €</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" style="text-align: right; font-weight: bold;">TOTAL (hors taxes/frais si applicable) :</td>
                        <td style="font-weight: bold;"><?= number_format($sous_total_commande, 2) ?> €</td>
                    </tr>
                </tfoot>
            </table>
        <?php else: ?>
            <p>Aucun article détaillé trouvé pour cette commande.</p>
        <?php endif; ?>
        
        <h3 style="margin-top: 30px;">Actions Administrateur</h3>
        <a href="commande_changer_statut.php?id=<?= $commande_id ?>&statut=traitée" class="btn-action">Marquer comme Traitée</a>
        <a href="commande_changer_statut.php?id=<?= $commande_id ?>&statut=envoyée" class="btn-action">Marquer comme Envoyée</a>
        <a href="commande_changer_statut.php?id=<?= $commande_id ?>&statut=livrée" class="btn-action">Marquer comme Livrée</a>
        <a href="commande_changer_statut.php?id=<?= $commande_id ?>&statut=annulée" class="btn-action" style="background-color: #f44336;">Annuler la Commande</a>
        
    <?php endif; ?>
</div>

</body>
</html>