<?php
// Fichier : pages/admin/fournisseurs.php
require_once 'securite.php'; // 🛡️ Sécurité : accès réservé aux Admins
require_once '../../includes/db_connect.php'; // Connexion BDD
require_once 'admin_header.php'; // En-tête et navigation Admin

$fournisseurs = [];
$message = '';

try {
    // 1. Récupération de tous les fournisseurs
    $stmt = $conn->query("SELECT id, nom, contact, email, telephone, ville FROM fournisseurs ORDER BY nom ASC");
    $fournisseurs = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $message = "Erreur lors de la récupération des fournisseurs : " . $e->getMessage();
}

?>

<div class="content">
    <h2>Liste des Fournisseurs</h2>
    
    <a href="fournisseur_ajouter.php" class="btn-primary">➕ Ajouter un Fournisseur</a>
    
    <?php if ($message): ?>
        <p style="color: red;"><?= $message ?></p>
    <?php endif; ?>

    <?php if (count($fournisseurs) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom de l'Entreprise</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Téléphone</th>
                    <th>Ville</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($fournisseurs as $f): ?>
                    <tr>
                        <td><?= $f['id'] ?></td>
                        <td><?= htmlspecialchars($f['nom']) ?></td>
                        <td><?= htmlspecialchars($f['contact']) ?></td>
                        <td><?= htmlspecialchars($f['email']) ?></td>
                        <td><?= htmlspecialchars($f['telephone']) ?></td>
                        <td><?= htmlspecialchars($f['ville']) ?></td>
                        <td>
                            <a href="fournisseur_modifier.php?id=<?= $f['id'] ?>" class="btn-edit">Modifier</a>
                            | 
                            <a href="fournisseur_supprimer.php?id=<?= $f['id'] ?>" 
                                onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce fournisseur ?')" 
                                class="btn-delete">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Aucun fournisseur trouvé. Commencez par en ajouter un !</p>
    <?php endif; ?>
</div>

<?php 
// Si vous avez un footer, incluez-le ici
// require_once 'admin_footer.php'; 
?>
</body>
</html>