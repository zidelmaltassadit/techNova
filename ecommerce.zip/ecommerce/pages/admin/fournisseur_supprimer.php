<?php
// Fichier : pages/admin/fournisseur_supprimer.php
require_once 'securite.php';
require_once '../../includes/db_connect.php';

// Récupération et validation de l'ID
$fournisseur_id = intval($_GET['id'] ?? 0);

if ($fournisseur_id > 0) {
    try {
        // Préparation de la suppression
        $stmt = $conn->prepare("DELETE FROM fournisseurs WHERE id = ?");
        $stmt->execute([$fournisseur_id]);
        
        // Redirection après succès
        header('Location: fournisseurs.php?success=deleted');
        exit;

    } catch (PDOException $e) {
        // Gérer l'erreur (ex: le fournisseur est lié à des produits)
        // Note: Vous devrez implémenter la suppression en cascade ou une vérification si le fournisseur est actif.
        $_SESSION['error_message'] = "Erreur de suppression : " . $e->getMessage();
        header('Location: fournisseurs.php');
        exit;
    }
} else {
    header('Location: fournisseurs.php?error=id_missing');
    exit;
}
?>