<?php 
// pages/admin/admin_header.php
// Ce fichier est inclus DANS les pages admin (après securite.php et db_connect.php)
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI Admin | Tableau de bord</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<header>
    <h2>🧰 PGI Administration</h2>
    <nav>
        <a href="dashboard.php">Tableau de bord</a>
        <a href="produits.php">Produits</a>
        <a href="categories.php">Catégories</a>
        <a href="commandes.php">Commandes</a>
        <a href="utilisateurs.php">Utilisateurs</a>
        <a href="fournisseurs.php">Fournisseurs</a> <a href="../../logout.php">Déconnexion</a>
    </nav>
</header>