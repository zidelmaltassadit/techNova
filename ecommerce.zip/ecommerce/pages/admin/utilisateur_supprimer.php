<?php
// Fichier : pages/admin/utilisateur_supprimer.php
require_once 'securite.php';
require_once '../../includes/db_connect.php';

$user_id = intval($_GET['id'] ?? 0);

if ($user_id > 0) {
    // Prévention de l'auto-suppression de l'administrateur
    if ($user_id === $_SESSION['user_id']) {
        $_SESSION['message'] = "❌ Erreur : Vous ne pouvez pas supprimer votre propre compte administrateur.";
        header('Location: utilisateurs.php');
        exit;
    }
    
    try {
        // Supprimer l'utilisateur. Attention : Si vous utilisez des contraintes de clés étrangères (ON DELETE CASCADE)
        // les commandes et autres données liées seront supprimées automatiquement. Sinon, la suppression échouera.
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        
        $_SESSION['message'] = "✅ Utilisateur (ID: {$user_id}) supprimé avec succès !";

    } catch (PDOException $e) {
        $_SESSION['message'] = "❌ Erreur de suppression BDD : L'utilisateur pourrait être lié à des commandes ou d'autres données. " . $e->getMessage();
    }
} else {
    $_SESSION['message'] = "❌ ID utilisateur manquant ou invalide.";
}

header('Location: utilisateurs.php');
exit;
?>