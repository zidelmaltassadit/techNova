<?php
session_start();
include("../includes/db_connect.php");

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Récupération des commandes de l'utilisateur
$req = $conn->prepare("
    SELECT * FROM commandes 
    WHERE user_id = ? 
    ORDER BY date_commande DESC
");
$req->execute([$user_id]);
$commandes = $req->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes commandes - E-commerce</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        main {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #2F80ED;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border-bottom: 1px solid #eee;
            padding: 12px;
            text-align: center;
        }
        th {
            background: #f5f5f5;
        }
        tr:hover {
            background: #f9f9f9;
        }
        .btn {
            display: inline-block;
            background: #2F80ED;
            color: white;
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #1C5FCC;
        }
        .empty {
            text-align: center;
            margin: 40px 0;
            color: #777;
            font-style: italic;
        }
    </style>
</head>
<body>

<header>
    <h2><a href="../index.php" style="color:white;text-decoration:none;">🛍️ E-Commerce</a></h2>
    <nav>
        <a href="../index.php">Accueil</a>
        <a href="panier.php">Panier (<?= isset($_SESSION['panier']) ? array_sum($_SESSION['panier']) : 0; ?>)</a>
        <a href="../logout.php">Déconnexion</a>
    </nav>
</header>

<main>
    <h1>📦 Mes commandes</h1>

    <?php if (empty($commandes)): ?>
        <p class="empty">Vous n'avez encore passé aucune commande.</p>
        <div style="text-align:center;">
            <a href="../index.php" class="btn">🛒 Commencer mes achats</a>
        </div>
    <?php else: ?>
        <table>
            <tr>
                <th>Numéro</th>
                <th>Date</th>
                <th>Total (€)</th>
                <th>Adresse</th>
                <th>Action</th>
            </tr>
            <?php foreach ($commandes as $c): ?>
                <tr>
                    <td>#<?= $c['id']; ?></td>
                    <td><?= date("d/m/Y H:i", strtotime($c['date_commande'])); ?></td>
                    <td><?= number_format($c['total'], 2, ',', ' '); ?></td>
                    <td><?= htmlspecialchars($c['adresse']); ?>, <?= htmlspecialchars($c['ville']); ?></td>
                    <td>
                        <a href="confirmation.php?id=<?= $c['id']; ?>" class="btn">🔍 Détails</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</main>

<footer>
    © <?= date('Y'); ?> - E-commerce | Tous droits réservés
</footer>

</body>
</html>
