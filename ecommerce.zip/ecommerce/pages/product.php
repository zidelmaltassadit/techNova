<?php
session_start();
include("../includes/db_connect.php");

// Vérifier que l'ID est bien passé
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../index.php");
    exit;
}

$id = intval($_GET['id']);

// Récupération du produit et de sa catégorie
$stmt = $conn->prepare("
    SELECT p.*, c.nom AS categorie 
    FROM produits p 
    LEFT JOIN categories c ON p.categorie_id = c.id 
    WHERE p.id = ?
");
$stmt->execute([$id]);
$produit = $stmt->fetch();

if (!$produit) {
    header("Location: ../index.php");
    exit;
}

// Gestion de l’ajout au panier
if (isset($_GET['ajouter'])) {
    $pid = intval($_GET['ajouter']);
    if (!isset($_SESSION['panier'][$pid])) {
        $_SESSION['panier'][$pid] = 1;
    } else {
        $_SESSION['panier'][$pid]++;
    }
    header("Location: panier.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($produit['nom']) ?> - Détails du produit</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .product-container {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
        }

        .product-container img {
            width: 320px;
            height: 320px;
            object-fit: cover;
            border-radius: 10px;
        }

        .product-info {
            flex: 1;
            min-width: 250px;
        }

        .product-info h2 {
            margin-top: 0;
            color: #2F80ED;
        }

        .price {
            font-size: 1.4em;
            color: #27AE60;
            margin: 10px 0;
        }

        .btn {
            background: #2F80ED;
            color: white;
            padding: 10px 18px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            margin-top: 15px;
        }

        .btn:hover {
            background: #1C5FCC;
        }

        .back {
            display: inline-block;
            margin-top: 30px;
            text-decoration: none;
            color: #2F80ED;
            font-weight: 500;
        }

        .back:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>
    <h2><a href="../index.php" style="color:white;text-decoration:none;">🛍️ E-Commerce</a></h2>
    <nav>
        <a href="../index.php">Accueil</a>
        <a href="panier.php">Panier (<?= isset($_SESSION['panier']) ? array_sum($_SESSION['panier']) : 0 ?>)</a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <span class="user-info">👤 Bonjour, <?= htmlspecialchars($_SESSION['user_nom']); ?></span>
            <a href="../logout.php">Déconnexion</a>
        <?php else: ?>
            <a href="../login.php">Connexion</a>
            <a href="../register.php">Inscription</a>
        <?php endif; ?>
    </nav>
</header>

<main>
    <div class="product-container">
        <img src="../assets/images/<?= htmlspecialchars($produit['image']) ?>" alt="<?= htmlspecialchars($produit['nom']) ?>">
        <div class="product-info">
            <h2><?= htmlspecialchars($produit['nom']) ?></h2>
            <p><strong>Catégorie :</strong> <?= htmlspecialchars($produit['categorie']) ?></p>
            <p class="price"><?= number_format($produit['prix'], 2, ',', ' ') ?> €</p>
            <p><?= nl2br(htmlspecialchars($produit['description'])) ?></p>
            <p><strong>Stock disponible :</strong> <?= $produit['stock'] ?></p>

            <?php if ($produit['stock'] > 0): ?>
                <a class="btn" href="panier.php?ajouter=<?= $produit['id'] ?>">🛒 Ajouter au panier</a>
            <?php else: ?>
                <p style="color:red;">❌ Produit en rupture de stock</p>
            <?php endif; ?>
        </div>
    </div>

    <div style="text-align:center;">
        <a class="back" href="../index.php">⬅ Retour à la boutique</a>
    </div>
</main>

<footer>
    © 2025 - E-commerce | Tous droits réservés
</footer>

</body>
</html>
