<?php
session_start();
include("../includes/db_connect.php");

// Initialiser le panier s'il n'existe pas
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

// Supprimer un article du panier
if (isset($_GET['supprimer'])) {
    $id = intval($_GET['supprimer']);
    unset($_SESSION['panier'][$id]);
    header("Location: panier.php");
    exit;
}

// Mettre à jour les quantités
if (isset($_POST['maj_panier'])) {
    foreach ($_POST['quantite'] as $id => $qte) {
        $qte = intval($qte);
        if ($qte <= 0) {
            unset($_SESSION['panier'][$id]);
        } else {
            $_SESSION['panier'][$id] = $qte;
        }
    }
    header("Location: panier.php");
    exit;
}

// Récupération des infos produits
$produits_panier = [];
$total = 0;

if (!empty($_SESSION['panier'])) {
    $ids = implode(',', array_keys($_SESSION['panier']));
    $req = $conn->query("SELECT * FROM produits WHERE id IN ($ids)");
    $produits_panier = $req->fetchAll();

    foreach ($produits_panier as $p) {
        $total += $p['prix'] * $_SESSION['panier'][$p['id']];
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Votre Panier - E-commerce</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        main {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #2F80ED;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border-bottom: 1px solid #eee;
            padding: 12px;
            text-align: center;
        }
        th {
            background: #f5f5f5;
        }
        img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 6px;
        }
        .total {
            text-align: right;
            font-size: 1.2em;
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            background: #2F80ED;
            color: white;
            padding: 8px 14px;
            border-radius: 6px;
            text-decoration: none;
            margin-top: 10px;
        }
        .btn:hover {
            background: #1C5FCC;
        }
        .empty {
            text-align: center;
            font-style: italic;
            color: #777;
        }
        .delete {
            color: red;
            text-decoration: none;
        }
        .delete:hover {
            text-decoration: underline;
        }
        .actions {
            text-align: right;
            margin-top: 15px;
        }
        input[type=number] {
            width: 60px;
            padding: 4px;
            text-align: center;
        }
    </style>
</head>
<body>

<header>
    <h2><a href="../index.php" style="color:white;text-decoration:none;">🛍️ E-Commerce</a></h2>
    <nav>
        <a href="../index.php">Accueil</a>
        <a href="panier.php">Panier (<?= isset($_SESSION['panier']) ? array_sum($_SESSION['panier']) : 0; ?>)</a>

        <?php if (isset($_SESSION['user_id'])): ?>
            <span class="user-info">👤 Bonjour, <?= htmlspecialchars($_SESSION['user_nom']); ?></span>
            <a href="../logout.php">Déconnexion</a>
        <?php else: ?>
            <a href="../login.php">Connexion</a>
            <a href="../register.php">Inscription</a>
        <?php endif; ?>
    </nav>
</header>

<main>
    <h1>🛒 Votre Panier</h1>

    <?php if (empty($produits_panier)): ?>
        <p class="empty">Votre panier est vide pour le moment.</p>
        <div style="text-align:center;">
            <a href="../index.php" class="btn">⬅ Continuer mes achats</a>
        </div>
    <?php else: ?>
        <form method="POST">
            <table>
                <tr>
                    <th>Image</th>
                    <th>Produit</th>
                    <th>Prix unitaire (€)</th>
                    <th>Quantité</th>
                    <th>Sous-total (€)</th>
                    <th>Action</th>
                </tr>

                <?php foreach ($produits_panier as $p): ?>
                <tr>
                    <td><img src="../assets/images/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['nom']) ?>"></td>
                    <td><?= htmlspecialchars($p['nom']) ?></td>
                    <td><?= number_format($p['prix'], 2, ',', ' ') ?></td>
                    <td>
                        <input type="number" name="quantite[<?= $p['id'] ?>]" value="<?= $_SESSION['panier'][$p['id']] ?>" min="1">
                    </td>
                    <td><?= number_format($p['prix'] * $_SESSION['panier'][$p['id']], 2, ',', ' ') ?></td>
                    <td><a href="panier.php?supprimer=<?= $p['id'] ?>" class="delete">🗑️ Supprimer</a></td>
                </tr>
                <?php endforeach; ?>
            </table>

            <div class="actions">
                <button type="submit" name="maj_panier" class="btn">🔄 Mettre à jour le panier</button>
            </div>
        </form>

        <p class="total"><strong>Total :</strong> <?= number_format($total, 2, ',', ' ') ?> €</p>

        <div style="text-align:right;">
            <a href="../index.php" class="btn">⬅ Continuer mes achats</a>
            <a href="commande.php" class="btn" style="background:#27AE60;">💳 Passer la commande</a>
        </div>
    <?php endif; ?>
</main>

<footer>
    © <?= date('Y'); ?> - E-commerce | Tous droits réservés
</footer>

</body>
</html>
