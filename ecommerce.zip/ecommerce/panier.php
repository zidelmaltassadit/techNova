<?php
// Fichier : panier.php (à la racine de votre projet)
session_start();
require_once 'includes/db_connect.php'; 
// Assurez-vous d'inclure le header client ici (non codé, mais nécessaire)
// include('header.php');

$panier = $_SESSION['panier'] ?? [];
$produits_panier = [];
$total_panier = 0;
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

if (count($panier) > 0) {
    // 1. Créer une liste de IDs séparés par des virgules pour la requête SQL
    $ids = implode(',', array_keys($panier));

    try {
        // 2. Récupérer les informations des produits en une seule requête
        $stmt = $conn->query("SELECT id, nom, prix FROM produits WHERE id IN ($ids)");
        $produits_db = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 3. Fusionner les données BDD avec les quantités de session
        foreach ($produits_db as $p) {
            $quantite = $panier[$p['id']];
            $sous_total = $p['prix'] * $quantite;
            $total_panier += $sous_total;

            $produits_panier[] = [
                'id' => $p['id'],
                'nom' => $p['nom'],
                'prix' => $p['prix'],
                'quantite' => $quantite,
                'sous_total' => $sous_total
            ];
        }
    } catch (PDOException $e) {
        $message = "Erreur BDD lors du chargement des produits : " . $e->getMessage();
    }
}

// Note : L'inclusion du header (qui ouvre <body>) est supposée être ici
// require_once 'header.php'; 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon Panier</title>
    </head>
<body>
    <div class="container">
        <h1>Mon Panier d'Achat 🛒</h1>
        
        <?php if ($message): ?>
            <p style="color: green;"><?= $message ?></p>
        <?php endif; ?>

        <?php if (count($produits_panier) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Produit</th>
                        <th>Prix Unitaire</th>
                        <th>Quantité</th>
                        <th>Sous-total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($produits_panier as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['nom']) ?></td>
                            <td><?= number_format($item['prix'], 2) ?> €</td>
                            <td>
                                <form method="POST" action="mise_a_jour_panier.php" style="display: inline-flex; gap: 5px;">
                                    <input type="hidden" name="produit_id" value="<?= $item['id'] ?>">
                                    <input type="hidden" name="action" value="update">
                                    <input type="number" name="quantite" value="<?= $item['quantite'] ?>" min="1" style="width: 60px;" required>
                                    <button type="submit">OK</button>
                                </form>
                            </td>
                            <td><?= number_format($item['sous_total'], 2) ?> €</td>
                            <td>
                                <form method="POST" action="mise_a_jour_panier.php" style="display: inline;">
                                    <input type="hidden" name="produit_id" value="<?= $item['id'] ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button type="submit" style="color: red;">Retirer</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" style="text-align: right; font-weight: bold;">TOTAL :</td>
                        <td colspan="2" style="font-weight: bold; font-size: 1.2em;"><?= number_format($total_panier, 2) ?> €</td>
                    </tr>
                </tfoot>
            </table>

            <div style="text-align: right; margin-top: 20px;">
                <a href="index.php">Continuer mes achats</a>
                |
                <a href="commander.php" style="background-color: green; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Passer la Commande</a>
            </div>

        <?php else: ?>
            <p>Votre panier est vide. 😢</p>
            <a href="index.php">Commencer vos achats</a>
        <?php endif; ?>
    </div>
</body>
</html>