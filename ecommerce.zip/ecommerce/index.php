<?php
// Fichier : index.php (Page d'accueil)
session_start();
// Vérifiez que le chemin vers db_connect.php est correct
include("includes/db_connect.php");

// Initialiser le panier s’il n’existe pas encore
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

// Récupération des produits depuis la base (ex: les 12 derniers)
$req = $conn->query("SELECT id, nom, prix, description, image FROM produits ORDER BY id DESC LIMIT 12");
$produits = $req->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil - Boutique E-commerce</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Styles ajoutés pour la lisibilité */
        body { font-family: sans-serif; margin: 0; }
        header { background-color: #2F80ED; color: white; padding: 10px 5%; display: flex; justify-content: space-between; align-items: center; }
        header nav a { color: white; text-decoration: none; margin-left: 15px; }
        header nav a:hover { text-decoration: underline; }
        main { padding: 20px 5%; }
        .produits { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 30px; }
        .card { border: 1px solid #ddd; padding: 15px; text-align: center; }
        .card img { max-width: 100%; height: auto; margin-bottom: 10px; }
        .card h3 { margin-top: 5px; font-size: 1.2em; }
        .card p { font-weight: bold; color: #2F80ED; }
        .card button.btn { background-color: #f0ad4e; color: white; border: none; padding: 10px 15px; cursor: pointer; margin-top: 10px; }
        .card a:last-child { color: #2F80ED; text-decoration: none; display: block; margin-top: 8px; }
        .user-info { margin-right: 15px; }
        .intro { text-align: center; color: #555; margin-bottom: 30px; }
        .empty-msg { text-align: center; color: #888; font-style: italic; margin-top: 30px; }
    </style>
</head>
<body>

<header>
    <h2>
        <a href="index.php" style="color:white;text-decoration:none;">🛍️ E-Commerce</a>
    </h2>
    <nav>
        <a href="index.php">Accueil</a>
        
        <a href="panier.php" class="panier">
            Panier (<?= isset($_SESSION['panier']) ? array_sum($_SESSION['panier']) : 0; ?>)
        </a>

        <?php if (isset($_SESSION['user_id'])): ?>
            <span class="user-info">👤 Bonjour, <?= htmlspecialchars($_SESSION['user_nom'] ?? 'Client'); ?></span>
            
            <a href="client_dashboard.php">Mon Compte</a>
            
            <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                <a href="pages/admin/dashboard.php" style="color: #ff0;">PGI Admin</a>
            <?php endif; ?>
            
            <a href="logout.php">Déconnexion</a>
        <?php else: ?>
            <a href="login.php">Connexion</a>
            <a href="register.php">Inscription</a>
        <?php endif; ?>
    </nav>
</header>

<main>
    <h1>Nos produits récents</h1>
    <p class="intro">Découvrez nos dernières nouveautés disponibles dès maintenant 🛒</p>

    <div class="produits">
        <?php if (empty($produits)): ?>
            <p class="empty-msg">Aucun produit disponible pour le moment.</p>
        <?php else: ?>
            <?php foreach ($produits as $p): ?>
                <div class="card">
                    <img src="assets/images/<?= htmlspecialchars($p['image'] ?? 'placeholder.jpg') ?>" alt="<?= htmlspecialchars($p['nom']) ?>">
                    
                    <h3><?= htmlspecialchars($p['nom']) ?></h3>
                    <p><?= number_format($p['prix'], 2, ',', ' ') ?> €</p>
                    
                    <form method="POST" action="ajouter_panier.php">
                        <input type="hidden" name="produit_id" value="<?= $p['id'] ?>">
                        <input type="hidden" name="quantite" value="1">
                        <button type="submit" class="btn">🛒 Ajouter au panier</button>
                    </form>
                    
                    <a href="produit.php?id=<?= $p['id'] ?>">🔍 Détails</a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>

<footer>
    <p style="text-align: center; padding: 10px; border-top: 1px solid #eee;">
        © <?= date('Y'); ?> - E-commerce | Tous droits réservés
    </p>
</footer>

</body>
</html>