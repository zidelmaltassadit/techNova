<?php
// Fichier : client_motdepasse.php (à la racine)
require_once 'client_secure.php'; 
require_once 'includes/db_connect.php'; 

$user_id = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ancien_motdepasse = $_POST['ancien_motdepasse'] ?? '';
    $nouveau_motdepasse = $_POST['nouveau_motdepasse'] ?? '';
    $confirmer_motdepasse = $_POST['confirmer_motdepasse'] ?? '';
    
    // 1. Récupérer le hachage du mot de passe actuel
    try {
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
    } catch (PDOException $e) {
        $message = "Erreur BDD : " . $e->getMessage();
    }
    
    if (!$user) {
        $message = "❌ Erreur utilisateur non trouvé.";
    } elseif (!password_verify($ancien_motdepasse, $user['password'])) {
        // 2. Vérification de l'ancien mot de passe
        $message = "❌ L'ancien mot de passe est incorrect.";
    } elseif (strlen($nouveau_motdepasse) < 8) {
        // 3. Vérification de la longueur du nouveau mot de passe
        $message = "❌ Le nouveau mot de passe doit contenir au moins 8 caractères.";
    } elseif ($nouveau_motdepasse !== $confirmer_motdepasse) {
        // 4. Vérification de la confirmation
        $message = "❌ Le nouveau mot de passe et sa confirmation ne correspondent pas.";
    } else {
        // 5. Tout est bon : Hachage et mise à jour
        $nouveau_hash = password_hash($nouveau_motdepasse, PASSWORD_DEFAULT);
        
        try {
            $stmt_update = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt_update->execute([$nouveau_hash, $user_id]);
            
            $message = "✅ Votre mot de passe a été mis à jour avec succès !";
            // Sécurité: Forcer une reconnexion après le changement (bonne pratique)
            // header('Location: logout.php?success=password_changed'); 
            // exit;
            
        } catch (PDOException $e) {
            $message = "❌ Erreur BDD lors de la mise à jour du mot de passe : " . $e->getMessage();
        }
    }
}

// require_once 'header.php'; // Inclure l'en-tête client
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Changer mon Mot de Passe</title>
</head>
<body>
    <div class="container">
        <h1>Changer mon Mot de Passe</h1>
        <p><a href="client_dashboard.php">← Retour à l'Espace Client</a></p>
        
        <?php if ($message): ?>
            <p style="color: <?= (strpos($message, '✅') !== false) ? 'green' : 'red' ?>;"><?= $message ?></p>
        <?php endif; ?>

        <form method="POST" action="client_motdepasse.php">
            
            <label for="ancien_motdepasse">Ancien Mot de Passe :</label>
            <input type="password" name="ancien_motdepasse" required><br><br>
            
            <label for="nouveau_motdepasse">Nouveau Mot de Passe (8 car. min) :</label>
            <input type="password" name="nouveau_motdepasse" required><br><br>
            
            <label for="confirmer_motdepasse">Confirmer le Nouveau Mot de Passe :</label>
            <input type="password" name="confirmer_motdepasse" required><br><br>
            
            <input type="submit" value="Mettre à jour le Mot de Passe">
        </form>
    </div>
</body>
</html>