<?php
// Fichier : ajouter_panier.php (à la racine de votre projet)
session_start();
// Pas besoin de db_connect ici, juste pour la logique session

// 1. Initialiser le panier s'il n'existe pas
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

// 2. Récupérer les paramètres
$produit_id = intval($_POST['produit_id'] ?? $_GET['id'] ?? 0);
$quantite = intval($_POST['quantite'] ?? 1); // Quantité par défaut : 1

if ($produit_id > 0 && $quantite > 0) {
    // 3. Ajouter ou incrémenter le produit dans la session
    if (isset($_SESSION['panier'][$produit_id])) {
        // Le produit est déjà dans le panier, incrémenter la quantité
        $_SESSION['panier'][$produit_id] += $quantite;
    } else {
        // Nouveau produit
        $_SESSION['panier'][$produit_id] = $quantite;
    }

    // 4. Redirection vers le panier ou confirmation
    // On peut rediriger vers la page panier pour que l'utilisateur voie le résultat
    header('Location: panier.php?added=' . $produit_id);
    exit;
}

// Si l'ID est invalide, rediriger vers la page d'accueil
header('Location: index.php?error=invalid_product');
exit;